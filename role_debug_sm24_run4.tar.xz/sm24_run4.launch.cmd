@echo off
cd /d "C:\Users\Horton\Desktop\EnergyPlus-Agent-dev"
set VIRTUAL_ENV=C:\Users\Horton\Desktop\EnergyPlus-Agent-dev\.venv
set PATH=C:\Users\Horton\Desktop\EnergyPlus-Agent-dev\.venv\Scripts;%PATH%
set PYTHONUTF8=1
set PYTHONPATH=C:\Users\Horton\Desktop\EnergyPlus-Agent-dev
set OPENBLAS_NUM_THREADS=1
"C:\Users\Horton\Desktop\EnergyPlus-Agent-dev\.venv\Scripts\python.exe" -m src.agent.runtime_configuration launch "AI_agent\logs\experiments\2026-10-07_role_division_debug\role_division_debug.json" --case sm24_role_division_debug4 > "C:\Users\Horton\Desktop\EnergyPlus-Agent-dev\AI_agent\archive\local_backup\role_debug\sm24_run4.stdout.log" 2> "C:\Users\Horton\Desktop\EnergyPlus-Agent-dev\AI_agent\archive\local_backup\role_debug\sm24_run4.stderr.log"
echo exit=%ERRORLEVEL% > "C:\Users\Horton\Desktop\EnergyPlus-Agent-dev\AI_agent\archive\local_backup\role_debug\sm24_run4.exit.txt"
