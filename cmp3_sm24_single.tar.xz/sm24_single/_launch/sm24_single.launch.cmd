@echo off
cd /d "C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-cmp3"
set VIRTUAL_ENV=C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-cmp3\.venv
set PATH=C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-cmp3\.venv\Scripts;%PATH%
set PYTHONUTF8=1
set PYTHONPATH=C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-cmp3
set OPENBLAS_NUM_THREADS=1
"C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-cmp3\.venv\Scripts\python.exe" -m src.agent.runtime_configuration launch "AI_agent\logs\experiments\2026-10-07_three_case_comparison\comparison.json" --case sm24_single_cmp > "C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-cmp3\AI_agent\archive\local_backup\cmp3\sm24_single.stdout.log" 2> "C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-cmp3\AI_agent\archive\local_backup\cmp3\sm24_single.stderr.log"
echo exit=%ERRORLEVEL% > "C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-cmp3\AI_agent\archive\local_backup\cmp3\sm24_single.exit.txt"
