@echo off
cd /d "C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-d1g"
set VIRTUAL_ENV=C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-d1g\.venv
set PATH=C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-d1g\.venv\Scripts;%PATH%
set PYTHONUTF8=1
set PYTHONPATH=C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-d1g
set OPENBLAS_NUM_THREADS=1
"C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-d1g\.venv\Scripts\python.exe" "AI_agent\logs\experiments\2026-10-07_reader_model_probe\run_probe.py" --model Qwen3.8-27B --name qwen27b_r1 --cap-cny 8 --credentials-file "C:\Users\Horton\Desktop\EnergyPlus-Agent-dev\.env" > "C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-d1g\AI_agent\archive\local_backup\reader_model_probe\qwen27b_r1.stdout.log" 2> "C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-d1g\AI_agent\archive\local_backup\reader_model_probe\qwen27b_r1.stderr.log"
echo exit=%ERRORLEVEL% > "C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-d1g\AI_agent\archive\local_backup\reader_model_probe\qwen27b_r1.exit.txt"
