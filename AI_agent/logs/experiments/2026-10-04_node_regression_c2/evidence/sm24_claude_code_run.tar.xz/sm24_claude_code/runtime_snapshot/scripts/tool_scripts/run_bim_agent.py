"""Small subscription-driven BIM experiment; no legacy flow or solver stages.

The model sees an explicit image inventory, an optional frozen user building
declaration, and the tools below. MCP owns file access and geometry execution;
the model has no shell/repository tools. This is an experimental entry point,
not a complete product orchestrator.
"""
from __future__ import annotations

import argparse
import hashlib
import html
import io
import json
import math
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from PIL import Image as PILImage, ImageDraw
from mcp.server.fastmcp import Image
from mcp.types import CallToolResult, TextContent


from scripts.tool_scripts.bim_agent_guidance import REFERENCES, build_guide, filter_tool_catalog, tool_capabilities
from scripts.tool_scripts.bim_agent_inputs import freeze_building_input, freeze_plan_input
from scripts.tool_scripts.bim_agent_feedback import ImageFilename


def dump(path: Path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def digest(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _inclusive_runs(flags):
    """Return exact inclusive intervals of truthy values without gap bridging."""
    runs = []
    start = None
    for index, flag in enumerate([*flags, False]):
        if bool(flag) and start is None:
            start = index
        elif not bool(flag) and start is not None:
            runs.append((start, index - 1))
            start = None
    return runs


def _empty_profile_diagnostics(pixels, rgb, counts, minimum_count, support_length):
    """Explain an empty colour filter without inferring walls or changing it."""
    import numpy as np
    if int(counts.max()) >= minimum_count:
        return None
    packed = pixels.astype(np.uint32)
    packed = ((packed[..., 0] << 16) | (packed[..., 1] << 8) | packed[..., 2]).ravel()
    values, frequencies = np.unique(packed, return_counts=True)
    colors = np.column_stack(((values >> 16) & 255, (values >> 8) & 255, values & 255))
    distances = np.linalg.norm(colors.astype(float) - np.asarray(rgb), axis=1)
    nearest = int(distances.argmin())
    order = np.argsort(-frequencies, kind="stable")[:8]
    return {
        "reason": "no_pixels_match_requested_color" if int(counts.sum()) == 0
                  else "matching_pixels_below_support_threshold",
        "nearest_observed_color": {"rgb": colors[nearest].tolist(),
                                   "distance": round(float(distances[nearest]), 6),
                                   "pixel_count": int(frequencies[nearest])},
        "frequent_observed_colors": [
            {"rgb": colors[i].tolist(), "pixel_count": int(frequencies[i])} for i in order],
        "total_crop_pixels": int(packed.size),
        "maximum_support_count": int(counts.max()),
        "maximum_support_fraction": round(float(counts.max()) / support_length, 6),
        "minimum_count": int(minimum_count),
        "interpretation": "These are exact crop colours and filter support, not object labels. "
                          "Reinspect the original and choose a suitable RGB/axis/threshold if needed. "
                          "An empty filter does not establish a missing wall or an open connection.",
    }


def _profile_axis(mask, box, axis, min_fraction):
    """Measure one projection of an existing mask, retaining exact peak support."""
    counts = mask.sum(axis=0 if axis == "x" else 1)
    projection_offset = box[0] if axis == "x" else box[1]
    support_offset = box[1] if axis == "x" else box[0]
    support_length = mask.shape[0] if axis == "x" else mask.shape[1]
    minimum_count = max(1, math.ceil(support_length * float(min_fraction)))
    runs = []
    for start, end in _inclusive_runs(counts >= minimum_count):
        peak = start + int(counts[start:end + 1].argmax())
        support = mask[:, peak] if axis == "x" else mask[peak, :]
        runs.append({
            "pixels": [start + projection_offset, end + projection_offset],
            "peak": peak + projection_offset,
            "max_count": int(counts[peak]),
            "max_fraction": round(float(counts[peak]) / support_length, 6),
            "support_intervals_at_peak": [
                [lo + support_offset, hi + support_offset]
                for lo, hi in _inclusive_runs(support)],
        })
    return counts, minimum_count, support_length, runs


def _profile_support_peaks(counts, offset):
    """Retain every positive local maximum plateau, without smoothing or ranking."""
    peaks = []
    start = 0
    for end in range(1, len(counts) + 1):
        if end < len(counts) and counts[end] == counts[start]:
            continue
        count = int(counts[start])
        left = int(counts[start - 1]) if start else 0
        right = int(counts[end]) if end < len(counts) else 0
        if count > 0 and count > left and count > right:
            peaks.append({"pixels": [start + offset, end - 1 + offset], "count": count})
        start = end
    return peaks


def _profile_excluded_support(counts, offset, minimum_count, support_length):
    """Expose positive ink omitted by the caller's threshold, without new candidates."""
    excluded = (counts > 0) & (counts < minimum_count)
    intervals = []
    for start, end in _inclusive_runs(excluded):
        values = counts[start:end + 1]
        intervals.append({
            "pixels": [start + offset, end + offset],
            "min_count": int(values.min()), "max_count": int(values.max()),
        })
    return {
        "coordinate_count": int(excluded.sum()),
        "matching_pixels": int(counts[excluded].sum()),
        "minimum_count": minimum_count,
        "support_length": support_length,
        "intervals": intervals,
        "note": "These coordinates contain matching ink but are below min_fraction; "
                "they are not empty background. Intervals use inclusive original pixels. "
                "Counts do not prove the same stroke continues between rows/columns. "
                "Compare the clean crop and cross-axis support, or choose a narrower crop "
                "or lower threshold after inspecting the original. No wall, opening or "
                "candidate is inferred; existing candidate IDs are unchanged.",
    }


def coordinate_grid_view(pic, region):
    """Label original pixels on a disposable model view, keeping its affine frame."""
    if min(pic.size) < 100:
        return pic, {"shown": False, "reason": "small unscaled detail"}
    pic = pic.copy()
    draw = ImageDraw.Draw(pic)
    x0, y0, x1, y1 = region
    sx, sy = pic.width / (x1-x0), pic.height / (y1-y0)
    step = 100 if max(x1-x0, y1-y0) < 800 else 200
    ticks = {"x": [], "y": []}
    def label(point, value):
        bounds = draw.textbbox(point, value)
        draw.rectangle((bounds[0]-2, bounds[1]-1, bounds[2]+2, bounds[3]+1), fill="black")
        draw.text(point, value, fill="white")
    for value in range(((x0+step-1)//step)*step, x1, step):
        x = round((value-x0)*sx)
        for y in range(0, pic.height, 16):
            draw.line([(x,y),(x,min(y+4,pic.height-1))], fill=(80,160,190))
        label((min(max(x+3, 3), pic.width-48), 3), f"x={value}")
        ticks["x"].append({"original_pixel":value,"display_pixel":x})
    for value in range(((y0+step-1)//step)*step, y1, step):
        y = round((value-y0)*sy)
        for x in range(0, pic.width, 16):
            draw.line([(x,y),(min(x+4,pic.width-1),y)], fill=(80,160,190))
        label((3,min(max(y+3,17),pic.height-16)), f"y={value}")
        ticks["y"].append({"original_pixel":value,"display_pixel":y})
    return pic, {"shown":True,"units":"original image pixels","ticks":ticks,
                 "note":"Blue dotted grid/white labels are viewing aids, not drawing evidence."}


def terminate_subscription(process):
    """Stop this invocation and nested review sessions, including their MCPs."""
    rows = subprocess.check_output(["ps", "-eo", "pid=,ppid="], text=True)
    parents = {int(pid): int(parent) for pid, parent in (row.split() for row in rows.splitlines())}
    descendants = {process.pid}
    while True:
        expanded = descendants | {pid for pid, parent in parents.items() if parent in descendants}
        if expanded == descendants:
            break
        descendants = expanded
    groups = set()
    for pid in descendants:
        try:
            group = os.getpgid(pid)
            if group != os.getpgrp():
                groups.add(group)
        except ProcessLookupError:
            pass
    for group in groups:
        try:
            os.killpg(group, signal.SIGTERM)
        except ProcessLookupError:
            pass
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        for group in groups:
            try:
                os.killpg(group, signal.SIGKILL)
            except ProcessLookupError:
                pass
        process.wait()


def run_guide(run: Path) -> str:
    """System prompt matching the run's admitted inputs and declared image kind."""
    manifest = json.loads((run / "inputs.json").read_text())
    mesh = bool(manifest.get("mesh_input"))
    kind = manifest.get("image_kind") or (("unknown" if mesh else "drawings") if manifest.get("images") else None)
    return build_guide(images=kind, mesh=mesh, **tool_capabilities(manifest))


def subscription(run: Path, prompt: str, *, model: str, name: str,
                 readonly: bool = False, timeout: int = 900,
                 log_run: Path | None = None, receipt_context: dict | None = None,
                 effort: str | None = None, exploratory_opus: bool = False):
    """Only the logged-in subscription; isolated cwd/env, explicit MCP tools.

    ``run`` is the MCP-visible workspace. ``log_run`` can retain a child
    observation's request, stream and receipt alongside its parent run.
    """
    if effort not in {None, "low", "medium"}:
        raise ValueError("effort must be low or medium when supplied")
    if model == "haiku" and effort is not None:
        raise ValueError("explicit effort is supported only for sonnet in this experiment")
    if model not in ({"sonnet", "haiku", "opus"} if exploratory_opus else {"sonnet", "haiku"}):
        raise ValueError("only configured subscription aliases are allowed")
    run = run.resolve()
    log_run = (log_run or run).resolve()
    manifest = json.loads((run / "inputs.json").read_text())
    provider = manifest.get("provider", "claude")
    if provider not in {"claude", "glm"}:
        raise ValueError("unsupported subscription provider")
    if provider == "glm" and exploratory_opus:
        raise ValueError("GLM routing cannot be combined with exploratory Opus")
    from src.agent.execution.subscription_json import _isolated_env, _redact_secrets, subscription_model_id
    routed_model = "glm-5.3-flash" if provider == "glm" else subscription_model_id(model)
    launcher = str(ROOT / "scripts/glm_code.sh") if provider == "glm" else "claude"
    command = [launcher, "-p", "--model", routed_model, "--tools", "",
               "--allowedTools", "mcp__bim__*", "--permission-mode", "dontAsk",
               "--strict-mcp-config", "--setting-sources", "",
               "--settings", '{"disableAllHooks":true}',
               "--no-session-persistence", "--output-format", "stream-json", "--verbose",
               "--system-prompt", ("Answer only the supplied local visual question using tools. "
                                    "Inspect a suitable crop; cite original pixel locations of marks. "
                                    "Separate door arcs, gaps and dimension ticks. State uncertainty; "
                                    "For line evidence, compare both profile axes; peak support at a junction "
                                    "is not a whole wall's extent or thickness. Inspect beyond both ends "
                                    "and trace adjoining space boundaries before calling an endpoint free. "
                                    "do not infer a connection just because rooms are adjacent. "
                                    "For dimension labels, use a magnified clean crop and bind each "
                                    "transcription to its actual label box, dimension line and adjacent "
                                    "extension endpoints in original pixels. Keep different chains separate. "
                                    "Use map_dimension_chain only after transcription. If arithmetic or "
                                    "the claimed endpoints conflict, recheck that local evidence once, then "
                                    "report unknown instead of inventing a missing segment. "
                                    "Check inputs or view_image metadata for remaining_seconds, answer early, "
                                    "and near the limit state explicit unexamined items. Do not plan the whole building."
                                    if readonly else run_guide(run))]
    if not readonly or model == "sonnet":
        command.extend(["--effort", effort or "medium"])
    server = [sys.executable, str(Path(__file__).resolve()), "serve", str(run), "--enabled-only"]
    if readonly:
        server.append("--readonly")
    command.extend(["--mcp-config", json.dumps({"mcpServers": {"bim": {
        "command": server[0], "args": server[1:], "alwaysLoad": True}}})])
    started = time.monotonic()
    from src.agent_runtime.agent_registry import agent_version_record
    agent_version = agent_version_record(ROOT)["version_id"]
    record = {"requested_model": routed_model, "requested_role": model, "provider": provider,
              "agent_version": agent_version,
              "channel": f"{provider} subscription; no paid API/fallback",
              "readonly": readonly, "timeout_seconds": timeout,
              "exploratory_opus": exploratory_opus,
              "effort": (effort or "medium") if not readonly or model == "sonnet" else None}
    if receipt_context:
        record.update(receipt_context)
    dump(log_run / f"{name}_request.json", {**record, "prompt": prompt,
                                       "system_prompt": command[command.index("--system-prompt")+1]})
    stdout_path, stderr_path = log_run / f"{name}_stream.jsonl", log_run / f"{name}_stderr.log"
    with tempfile.TemporaryDirectory(prefix="bim-agent-cwd-") as cwd:
        with stdout_path.open("x") as stdout, stderr_path.open("x") as stderr:
            env = {**_isolated_env(), "ENABLE_TOOL_SEARCH": "false"}
            if provider == "glm":
                env.update(GLM_MODEL=routed_model, GLM_SMALL_MODEL=routed_model)
            deadline = manifest.get("deadline_epoch")
            if deadline is not None and deadline <= time.time():
                record.update(timed_out=True, model_process_started=False)
            else:
                process = subprocess.Popen(command, cwd=cwd, env=env,
                                           stdin=subprocess.PIPE, stdout=stdout, stderr=stderr,
                                           text=True, start_new_session=True)
                try:
                    available = min(timeout, max(0, deadline - time.time())) if deadline else timeout
                    process.communicate(prompt, timeout=available)
                    record["returncode"] = process.returncode
                except subprocess.TimeoutExpired:
                    terminate_subscription(process)
                    record["timed_out"] = True
    for path in (stdout_path, stderr_path):
        path.write_text(_redact_secrets(path.read_text()))
    record["elapsed_seconds"] = round(time.monotonic() - started, 2)
    for line in stdout_path.read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get("type") == "system" and event.get("subtype") == "init":
            record["actual_model"] = event.get("model")
        if event.get("type") == "result":
            record["result"] = event
    if provider == "glm" and record.get("actual_model") != routed_model:
        record["routing_error"] = "GLM invocation did not confirm the requested image model"
    if provider == "claude" and model == "sonnet":
        used_models = record.get("result", {}).get("modelUsage", {})
        if record.get("actual_model") != routed_model or any(used != routed_model for used in used_models):
            record["routing_error"] = "Claude invocation did not stay on the pinned Sonnet 5 model"
    dump(log_run / f"{name}_receipt.json", record)
    return record


DETAIL_MAX_TIMEOUT_SECONDS = 240
DETAIL_COMPLETION_RESERVE_SECONDS = 45
DETAIL_MIN_TIMEOUT_SECONDS = 15
DETAIL_OBSERVATION_LOCK = threading.Lock()


def prepare_detail_observation(
        toolkit: "Toolkit", question: str, images: list[str], name: str, *,
        timeout_seconds: float | None = None, deadline_epoch: float | None = None):
    """Make one immutable, image-only MCP workspace for a local observation."""
    if not isinstance(question, str) or not question.strip():
        raise ValueError("local review question must be non-empty")
    if not images:
        raise ValueError("choose at least one original image for local review")
    if len(set(images)) != len(images):
        raise ValueError("choose each local review image only once")
    if timeout_seconds is not None and deadline_epoch is not None:
        raise ValueError("choose either timeout_seconds or deadline_epoch for local review")
    if timeout_seconds is not None:
        if timeout_seconds <= 0:
            raise ValueError("local review timeout_seconds must be positive")
        deadline_epoch = time.time() + timeout_seconds
    if deadline_epoch is not None and deadline_epoch <= time.time():
        raise ValueError("local review deadline_epoch must be in the future")
    sources = {image: toolkit.image_path(image) for image in images}
    child = toolkit.run / name
    child.mkdir(exist_ok=False)
    child_images = child / "images"
    child_images.mkdir()
    selected = {}
    for image, source in sources.items():
        target = child_images / image
        shutil.copy2(source, target)
        with PILImage.open(target) as picture:
            size = list(picture.size)
        selected[image] = {"size": size, "sha256": digest(target)}
        if selected[image]["sha256"] != toolkit.manifest["images"][image]["sha256"]:
            raise ValueError("selected original image changed while preparing local review")
    # Keep the caller's wording verbatim. File isolation cannot make a leading
    # question independent if the caller itself includes a candidate claim.
    (child / "question.txt").write_text(question, encoding="utf-8")
    manifest = {
        "images": selected,
        "provider": toolkit.manifest.get("provider", "claude"),
        "input_mode": "isolated_detail_observation",
        "only_input": (
            "selected original image copies and local question; no parent scope, "
            "seed, candidates, history or evaluation"
        ),
        "question_sha256": hashlib.sha256(question.encode("utf-8")).hexdigest(),
    }
    if deadline_epoch is not None:
        # This is part of the immutable child input before its digest is recorded.
        # The readonly server reads it to expose remaining_seconds to its tools.
        manifest["deadline_epoch"] = deadline_epoch
    dump(child / "inputs.json", manifest)
    return child, digest(child / "inputs.json")


def review_detail_observation(
        toolkit: "Toolkit", question: str, images: list[str], *,
        timeout_seconds: float = DETAIL_MAX_TIMEOUT_SECONDS, invoke=subscription) -> dict:
    """Run one bounded, readonly local observation and retain parent receipts."""
    if (isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, (int, float))
            or not DETAIL_MIN_TIMEOUT_SECONDS <= timeout_seconds <= DETAIL_MAX_TIMEOUT_SECONDS):
        raise ValueError(f"timeout_seconds must be between {DETAIL_MIN_TIMEOUT_SECONDS} and {DETAIL_MAX_TIMEOUT_SECONDS}")
    # FastMCP may serve sync tools concurrently. Keep allocation, receipt creation
    # and the bounded invocation together so two calls cannot both claim detail_01.
    with DETAIL_OBSERVATION_LOCK:
        used = len(list(toolkit.run.glob("detail_*_request.json")))
        if used >= 2:
            return {"error": "local review budget exhausted", "completed": False}
        parent_deadline = toolkit.manifest.get("deadline_epoch")
        remaining = toolkit.remaining_seconds()
        if remaining is not None:
            child_deadline = min(time.time() + timeout_seconds,
                                 float(parent_deadline) - DETAIL_COMPLETION_RESERVE_SECONDS)
            timeout = child_deadline - time.time()
            if timeout < DETAIL_MIN_TIMEOUT_SECONDS:
                return {"error": "insufficient remaining budget for local review",
                        "completed": False, "remaining_seconds": remaining}
            # Keep the parent completion reserve outside the child workspace too.
            # This exact absolute deadline avoids extending the child's budget while
            # it is being prepared or while the parent waits for it to return.
            # ``timeout`` is also capped by that deadline, not a rounded display value.
        else:
            timeout = timeout_seconds
            child_deadline = time.time() + timeout
        name = f"detail_{used + 1:02d}"
        child, input_sha256 = prepare_detail_observation(
            toolkit, question, images, name, deadline_epoch=child_deadline)
        source = {"run": name, "input_sha256": input_sha256,
                  "images": {image: toolkit.manifest["images"][image]["sha256"] for image in images}}
        # Image copying/manifest writing consume time too. Do not let the process
        # outlive the deadline the readonly tools were shown.
        timeout = min(timeout_seconds, child_deadline - time.time())
        result = invoke(child, f"Images: {images}\nQuestion: {question}", model="haiku", name=name,
                        readonly=True, timeout=timeout, log_run=toolkit.run,
                        receipt_context={"observation_source": source})
        result_event = result.get("result")
        completed = (bool(result_event) and not result_event.get("is_error", False)
                     and not result.get("timed_out", False) and result.get("returncode") == 0
                     and not result.get("routing_error"))
        return {"actual_model": result.get("actual_model"),
                "timed_out": result.get("timed_out", False),
                "returncode": result.get("returncode"),
                "result": result_event.get("result", "No completed answer") if result_event else "No completed answer",
                "is_error": result_event.get("is_error", False) if result_event else True,
                "completed": completed,
                "routing_error": result.get("routing_error"),
                "observation_source": source,
                "remaining_seconds": toolkit.remaining_seconds()}


def cost_receipt_summary(run: Path):
    """Read each root receipt once; detail child folders deliberately have none."""
    receipts = [json.loads(path.read_text()) for path in sorted(run.glob("*_receipt.json"))]
    estimates = [receipt.get("result", {}).get("total_cost_usd") for receipt in receipts]
    complete = all(isinstance(value, (int, float)) for value in estimates)
    partial = sum(value for value in estimates if isinstance(value, (int, float)))
    return receipts, {"estimated_cost_usd": partial if complete else None,
                      "cost_receipts_complete": complete,
                      "reported_partial_cost_usd": partial}


def delivery_tool_reply(result: dict) -> dict:
    """Keep full reports on disk; avoid losing a large handoff to CLI truncation."""
    from collections import Counter

    # The subscription client pretty-prints structured tool results. Measuring
    # only dense JSON underestimated run53's actual response by almost 30k chars.
    def fits(value):
        return len(json.dumps(value, ensure_ascii=False, indent=2)) <= 18000

    reply = {k:v for k,v in result.items() if k != 'opening_inventory'}
    if 'height_coverage' in reply:
        from src.agent.execution.bim_height_coverage import compact_height_coverage
        reply['height_coverage'] = compact_height_coverage(reply['height_coverage'])
    if 'located_height_coverage' in reply and 'openings' in reply['located_height_coverage']:
        from scripts.tool_scripts.bim_agent_facade_checks import compact_located_heights
        reply['located_height_coverage'] = compact_located_heights(reply['located_height_coverage'])
    if fits(reply):
        return reply
    large = {'facade_inventory', 'opening_review_scopes', 'facade_review_scopes',
             'current_reviews', 'stale_reviews', 'current_claim_state',
             'source_image_feedback', 'space_relation_review'}
    compact = {k:v for k,v in reply.items() if k not in large}
    state = result.get('current_claim_state', {})
    compact['current_claim_summary'] = {
        'state_counts': dict(Counter(row['state'] for row in state.get('claims', []))),
        'claims_with_missing_bindings': [row['id'] for row in state.get('claims', [])
                                        if row.get('missing_bindings')],
        'inherited_observation_count': len(state.get('inherited_observations', [])),
        'drawing_fidelity': 'not_evaluated',
    }
    height = result.get('height_coverage')
    if height is not None:
        compact['height_coverage'] = {key: height[key] for key in
            ('candidate', 'summary', 'drawing_fidelity', 'delivery_blocked', 'note') if key in height}
        compact['height_coverage']['floor_facade_summary'] = [{
            'floor_id': floor['floor_id'], 'facade': scope.get('facade'),
            'opening_count': len(scope['actual_opening_ids']),
            'image_linked_count': len(scope['image_evidence_linked_opening_ids']),
            'unchecked_count': len(scope['unchecked_height_opening_ids']),
        } for floor in height.get('floors', [])
            for scope in [*floor['facades'], floor['non_facade']]]
    projection = result.get('source_image_feedback', {})
    compact['source_image_feedback_summary'] = {key + '_count': len(projection.get(key, [])) for key in (
        'current_source_projections', 'old_source_projections', 'projection_errors',
        'registered_calibration_uncovered_floors', 'floors_without_registered_views')}
    relations = result.get('space_relation_review', {})
    compact['space_relation_review_summary'] = {key: value for key, value in relations.items()
                                               if not isinstance(value, (dict, list))}
    compact.update(response_compacted=True, full_delivery_report='delivery.json',
                   omitted_detail_fields=sorted(large | {'opening_inventory'}),
                   detail_note='Full nested evidence remains in delivery.json. Height endpoints and IDs '
                               'are available from check_openings(heights_only=true); claim_status(candidate) '
                               'contains current bindings. Summarized counts are not fidelity approval.',
                   review_scope_status_counts={key:dict(Counter(
                       row['review_status'] for row in result.get(key, [])))
                       for key in ['opening_review_scopes', 'facade_review_scopes']},
                   current_review_count=len(result.get('current_reviews', [])),
                   stale_review_count=len(result.get('stale_reviews', [])))
    if fits(compact):
        return compact
    # Even a long user note or hundreds of floors must not hide the actual
    # completion/uncertainty state behind a transport error.
    minimal = {key: compact[key] for key in (
        'candidate', 'viewer', 'source_model', 'source_model_sha256', 'counts',
        'selection_origin', 'drawing_fidelity', 'response_compacted',
        'full_delivery_report', 'review_scope_status_counts', 'current_review_count',
        'stale_review_count', 'source_image_feedback_summary', 'space_relation_review_summary',
        'room_use_review',
    ) if key in compact}
    minimal.update(detail_level='counts_only', more_details_omitted=True,
        generation_state=result.get('generation_status', {}).get('state'),
        source_validation_status=(result.get('source_validation') or {}).get('status'),
        source_validation_finding_count=len((result.get('source_validation') or {}).get('findings', [])),
        assumption_count=len(result.get('assumptions', [])),
        unresolved_count=len(result.get('generation', {}).get('unresolved', [])),
        adopted_unapplied_claim_count=len(result.get('adopted_unapplied_claims', [])),
        claim_state_counts=compact['current_claim_summary']['state_counts'],
        claims_with_missing_bindings_count=len(compact['current_claim_summary']['claims_with_missing_bindings']),
        failed_claim_application_count=sum(row.get('status') == 'failed'
                                           for row in result.get('claim_applications', [])))
    if 'floor_completeness' in result:
        floors = result['floor_completeness']
        minimal['floor_completeness'] = {key: floors[key] for key in (
            'complete_building', 'missing_candidate_images', 'floor_scope_source')}
    if 'located_height_coverage' in result:
        located = result['located_height_coverage']
        minimal['located_height_coverage'] = {key: located[key] for key in (
            'summary', 'unchecked_opening_ids', 'priority_opening_ids', 'delivery_blocked') if key in located}
    if 'facade_counts' in result:
        counts = result['facade_counts']
        minimal['facade_counts'] = {key: counts[key] for key in ('summary', 'delivery_blocked', 'status', 'reason') if key in counts}
        minimal['facade_counts']['full_scopes'] = 'delivery.json:facade_counts.scopes'
    if height is not None:
        summary = height['summary']
        minimal['height_coverage'] = {'summary': {key: summary[key] for key in
            ('total_count', 'image_linked_count', 'non_image_linked_count')},
            'unchecked_count': len(summary['unchecked_height_opening_ids']),
            'drawing_fidelity': 'not_evaluated'}
    views = result.get('input_view_status', {})
    minimal['input_view_summary'] = {
        'no_direct_view_count': len(views.get('no_direct_view_images', [])),
        'crop_only_count': len(views.get('crop_only_images', []))}
    return minimal


class Toolkit:
    def __init__(self, run: Path, readonly=False):
        self.run = run.resolve()
        self.manifest = json.loads((self.run / "inputs.json").read_text())
        self.readonly = readonly

    def candidate_budget(self):
        # Missing values belong to historical six-candidate experiments.
        limit = self.manifest.get("max_candidates", 6)
        if type(limit) is not int or limit <= 0:
            raise ValueError("max_candidates must be a positive integer")
        used = len(list(self.run.glob("candidate_*")))
        return {"limit": limit, "used": used, "remaining": max(0, limit - used)}

    def claims(self):
        from src.agent.execution.bim_claims import ClaimStore
        return ClaimStore(self)

    def record_claim(self, claim_json):
        if self.readonly:
            raise ValueError("only the coordinator may record candidate claims")
        data = json.loads(claim_json)
        if isinstance(data, dict) and data.get("observation_type") == "facade_count":
            from scripts.tool_scripts.bim_agent_facade_checks import record_facade_count
            result = record_facade_count(self, data)
        else:
            result = self.claims().record(data)
        self.log("record_claim", result)
        return result

    def decide_claim(self, claim_id, disposition, reason):
        if self.readonly:
            raise ValueError("only the coordinator may decide candidate claims")
        result = self.claims().decide(claim_id, disposition, reason)
        self.log("decide_claim", result)
        return result

    def replace_claim_sources(self, claim_id, view_ids, reason):
        if self.readonly:
            raise ValueError("only the coordinator may replace claim sources")
        result = self.claims().replace_sources(claim_id, view_ids, reason)
        self.log("replace_claim_sources", result)
        return result

    def confirm_claims(self, candidate, operations_json):
        if self.readonly:
            raise ValueError("only the coordinator may confirm candidate claims")
        from src.agent.execution.bim_claim_state import confirm
        result = confirm(self.claims(), candidate, json.loads(operations_json))
        result["located_height_coverage"] = self.located_heights(candidate)
        self.log("confirm_claims", result)
        return result

    def revise(self, candidate, operations_json):
        """Resolve evidence values, use the existing edits, then record actual outcome."""
        import copy
        from src.agent.execution.bim_claims import geometry_state, objects, sha, parameter_slots
        from src.agent.geometry.component_attributes import thickness_record
        from src.agent.geometry.proposal_edits import apply_proposal_edits
        if self.readonly:
            raise ValueError("only the coordinator may revise BIM")
        store = self.claims()
        submitted = json.loads(operations_json)
        def references(value):
            if isinstance(value, dict):
                found = {value["claim"]} if isinstance(value.get("claim"), str) else set()
                return found | set().union(*(references(v) for v in value.values()))
            if isinstance(value, list):
                return set().union(*(references(v) for v in value))
            return set()
        application = store._write("application", {"parent_candidate": candidate,
            "submitted_operations": submitted, "claim_ids": sorted(references(submitted)),
            "status": "pending", "drawing_fidelity": "not_evaluated"})
        application_path = store.folder / f"{application['id']}.json"
        try:
            parent, parent_source = store.candidate(candidate)
            operations, evidence = store.resolve_operations(candidate, submitted)
            application.update(evidence=evidence, resolved_operations=operations)
            updated = copy.deepcopy(parent)
            for operation in operations:
                if operation.get("op") != "set_component_thickness":
                    updated = apply_proposal_edits(updated, [operation])
                    continue
                if set(operation) != {"op", "boundary_id", "thickness_m", "basis", "reason", "source_refs"}:
                    raise ValueError("set_component_thickness requires boundary_id/thickness_m/basis/reason/source_refs")
                if not isinstance(operation["reason"], str) or not operation["reason"].strip():
                    raise ValueError("thickness edit requires a reason")
                record = thickness_record(parent_source, operation["boundary_id"], operation["thickness_m"],
                    basis=operation["basis"], source_refs=operation["source_refs"])
                ids = set(record["boundary_ids"])
                before = updated.get("component_attributes", [])
                updated["component_attributes"] = [row for row in before if not ids.intersection(row["boundary_ids"])] + [record]
                updated["geometry"].setdefault("corrections", []).append({"operation": "set_component_thickness",
                    "reason": operation["reason"], "before": before,
                    "after": updated["component_attributes"], "geometry_effect": "none"})
            # Evidence and computed parameter mapping survive proposal-only recovery.
            if evidence["bindings"]:
                updated["geometry"].setdefault("corrections", []).append({"operation": "claim_application",
                    "application_id": application["id"], **evidence})
            old_objects, new_objects = objects(parent, parent_source), objects(updated, parent_source)
            changes = [{"kind": key[0], "id": key[1], "before": old_objects.get(key), "after": new_objects.get(key)}
                       for key in sorted(old_objects.keys() | new_objects.keys())
                       if key[0] != "boundary" and old_objects.get(key) != new_objects.get(key)]
            expected = set()
            supported = True
            for operation in operations:
                name = operation["op"]
                if name in {"update_opening", "update_window"}:
                    expected.add((name.removeprefix("update_"), operation["id"]))
                elif name == "add_opening":
                    expected.add(("opening", operation["opening"]["id"]))
                elif name == "remove_opening":
                    expected.update((kind, operation["id"]) for kind in ("window", "opening")
                                    if (kind, operation["id"]) in old_objects)
                elif name == "move_shared_wall":
                    expected.update(("space", identity) for identity in operation["space_ids"])
                elif name == "reshape_spaces":
                    expected.update(("space", row["id"]) for row in operation["spaces"])
                elif name not in {"set_component_thickness", "replace_note", "set_notes", "resolve_unbuilt_observation"}:
                    supported = False
            for audit in updated["geometry"].get("corrections", [])[len(parent["geometry"].get("corrections", [])):]:
                expected.update(("opening", row["id"]) for row in audit.get("moved_openings", []))
            application.update(geometry_before_sha256=sha(geometry_state(parent)),
                geometry_after_sha256=sha(geometry_state(updated)), changes=changes,
                scope_check="checked" if supported else "not_supported_for_all_operations",
                outside_declared_scope=[row for row in changes if (row["kind"], row["id"]) not in expected] if supported else None)
            bound_slots = {(row["operation_index"], row["parameter"]) for row in evidence["bindings"]}
            application["parameters_without_claims"] = [
                {"operation_index": index, "parameter": field}
                for index, operation in enumerate(operations)
                for _, _, field, _, _ in parameter_slots(operation)
                if (index, field) not in bound_slots]
            result = self.build(updated, action="revise_bim", parent=candidate, operations=operations,
                                claim_application={"file": str(application_path.relative_to(self.run)), **evidence})
            application.update(candidate=result.get("candidate"), source_model_sha256=result.get("source_model_sha256"),
                status="applied" if result.get("source_geometry_ready") else "failed",
                source_geometry_ready=result.get("source_geometry_ready", False),
                error=result.get("error"), source_validation=result.get("source_validation"))
        except Exception as error:
            application.update(status="failed", error=str(error))
            dump(application_path, application)
            self.log("claim_application", application)
            raise
        dump(application_path, application)
        if result.get("candidate"):
            dump(self.candidate_path(result["candidate"]) / "application.json", application)
            result["located_height_coverage"] = self.located_heights(result["candidate"])
        self.log("claim_application", application)
        result["claim_application"] = application
        # Keep the saved provenance and its source digest unchanged. Only the
        # model-facing copy drops evidence already in the application file.
        if "provenance" in result:
            result["provenance"] = {**result["provenance"],
                "claim_application": {"file": str(application_path.relative_to(self.run))}}
        return result

    def log(self, action, data):
        with (self.run / "tools.jsonl").open("a") as stream:
            stream.write(json.dumps({"time": time.time(), "readonly": self.readonly,
                                     "action": action, "data": data}, ensure_ascii=False) + "\n")

    def candidate_path(self, candidate):
        allowed = {p.name for p in self.run.glob("candidate_*") if p.is_dir()}
        if (self.run / "seed").is_dir():
            allowed.add("seed")
        if candidate not in allowed:
            raise ValueError("unknown candidate")
        return self.run / candidate

    def remaining_seconds(self):
        deadline = self.manifest.get("deadline_epoch")
        return max(0, round(deadline - time.time())) if deadline else None

    def located_heights(self, candidate, current_state=None, *, compact=True):
        from scripts.tool_scripts.bim_agent_facade_checks import located_height_report, compact_located_heights
        try:
            report = located_height_report(self, candidate, current_state)
            return compact_located_heights(report) if compact else report
        except (OSError, ValueError, KeyError, TypeError) as error:
            # Advisory calculations must not turn a successful save into a failed build.
            return {"status": "unavailable", "reason": str(error), "delivery_blocked": False}

    def facade_counts(self, candidate):
        from scripts.tool_scripts.bim_agent_facade_checks import facade_count_report
        try:
            return facade_count_report(self, candidate)
        except (OSError, ValueError, KeyError, TypeError) as error:
            return {"status": "unavailable", "reason": str(error), "delivery_blocked": False}

    def input_view_status(self):
        """Report direct original-image returns, never inferred visual review."""
        images = self.manifest.get("images", {})
        views = {name: [] for name in images}
        log = self.run / "tools.jsonl"
        for line in log.read_text().splitlines() if log.exists() else []:
            event = json.loads(line)
            if event.get("action") != "view_image":
                continue
            data = event["data"]
            name = data.get("name")
            # Older logs without a bound image hash remain uncounted.
            if name not in images or data.get("image_sha256") != images[name]["sha256"]:
                continue
            views[name].append(data["box_original_pixels"])
        rows = []
        for name, info in sorted(images.items()):
            whole = [0, 0, *info["size"]]
            full = sum(box == whole for box in views[name])
            rows.append({"image": name, "image_sha256": info["sha256"],
                         "full_view_count": full, "crop_view_count": len(views[name]) - full,
                         "status": "full_view_returned" if full else
                                   "crop_only_returned" if views[name] else "no_direct_view_record"})
        return {"schema_version": "input_direct_view_status_v1", "images": rows,
                "no_direct_view_images": [row["image"] for row in rows
                                          if row["status"] == "no_direct_view_record"],
                "crop_only_images": [row["image"] for row in rows
                                     if row["status"] == "crop_only_returned"],
                "drawing_fidelity": "not_evaluated", "delivery_blocked": False,
                "note": "Only this run's hash-bound direct original returns from view_image or paired elevation views are counted. Other image tools, "
                        "workers and prior runs are outside this scope. A returned image is not proof "
                        "of examination, complete coverage, correct interpretation or applied heights. "
                        "Use supplied relevant elevations to check each floor's opening heights; "
                        "do not transfer a typical height to an unexamined opening family."}

    def delivery(self, candidate, *, selection_origin, generation_status=None):
        """Build the handoff from saved source/check records, never model prose."""
        from src.agent.geometry.bim_delivery import summarize_delivery
        path = self.candidate_path(candidate)
        source = json.loads((path / "source_model.json").read_text())
        reviews = [json.loads(p.read_text()) for p in
                   sorted((self.run / "opening_reviews").glob("review_*.json"))]
        calibrations = {(row["image"], row["floor_id"]): row for _, row in self.registered_calibrations()}
        for review in reviews:
            location = review.get("location_check", {})
            if location.get("status") != "checked_against_supplied_plan_boxes":
                continue
            current = calibrations.get((review.get("image", {}).get("name"),
                                        review.get("review_scope", {}).get("floor_id")), {})
            if (any(location.get(key) != current.get(key) for key in ("x_anchors", "y_anchors"))
                    or review.get("image", {}).get("sha256") != current.get("image_sha256")):
                review["stale_reason"] = "plan_calibration_changed"
        result = {"candidate": candidate, "selection_origin": selection_origin,
                  "viewer": f"{candidate}/viewer.html", "source_model": f"{candidate}/source_model.json",
                  "viewer_exists": (path / "viewer.html").is_file(),
                  "generation_status": generation_status or {"state":"in_progress"},
                  **summarize_delivery(source, reviews)}
        result["source_image_feedback"] = self._delivery_projection_status(candidate, source)
        result["space_relation_review"] = self.space_relation_status(source)
        result["input_view_status"] = self.input_view_status()
        from src.agent.roles import room_use_review
        result["room_use_review"] = room_use_review(source)
        claim_state = self.claims().status()
        from src.agent.execution.bim_claim_state import project
        current_claims = project(self.claims(), candidate)
        result["current_claim_state"] = current_claims
        from src.agent.execution.bim_height_coverage import height_coverage
        result["height_coverage"] = height_coverage(self.claims(), candidate, current_claims)
        result["located_height_coverage"] = self.located_heights(candidate, current_claims, compact=False)
        result["facade_counts"] = self.facade_counts(candidate)
        from scripts.tool_scripts.bim_agent_budget import saved_floor_status
        result["floor_completeness"] = saved_floor_status(self, candidate)
        # Keep full claims in their files; summarize unresolved execution in handoff.
        result["claim_applications"] = [{key: row.get(key) for key in
            ("id", "parent_candidate", "candidate", "claim_ids", "status", "error", "parameters_without_claims")}
            for row in claim_state["applications"]]
        result["adopted_unapplied_claims"] = [row["id"] for row in current_claims["claims"]
            if row["state"] in {"pending_application", "partially_satisfied", "changed_since_check"}]
        dump(self.run / "delivery.json", result)
        # A separate handoff preserves the immutable candidate's original report.
        statuses = {"not_reviewed":"未回查", "partial":"仅有局部回查",
                    "consistent_with_supplied_observations":"与所报观察一致",
                    "observations_require_follow_up":"仍需跟进"}
        kinds = {"door":"门洞", "window":"窗", "passage":"空通道"}
        scopes = result["opening_review_scopes"]
        rows = "".join(
            f'<tr><td>{html.escape(s["floor_id"])}</td><td>{kinds[s["kind"]]}</td>'
            f'<td>{s["built_count"]}</td><td>{statuses[s["review_status"]]}</td></tr>'
            for s in scopes)
        facades = {"North":"北", "South":"南", "East":"东", "West":"西"}
        facade_scopes = result.get("facade_review_scopes", [])
        facade_rows = "".join(
            f'<tr><td>{html.escape(s["floor_id"])}</td><td>{facades[s["facade"]]}</td>'
            f'<td>{kinds[s["kind"]]}</td><td>{s["built_count"]}</td>'
            f'<td>{statuses[s["review_status"]]}</td></tr>' for s in facade_scopes)
        facade_table = (
            '<details><summary>逐立面回查范围</summary>'
            '<p>零个已建开口也需明确观察；内部及无法确定方向的开口不能靠立面回查覆盖。'
            '与所报观察一致仍不代表原图保真。</p><table>'
            '<tr><th>楼层</th><th>立面</th><th>类别</th><th>已建数量</th><th>回查状态</th></tr>'
            f'{facade_rows}</table></details>' if facade_rows else '')
        count_report = result['facade_counts']
        count_labels = {'not_counted': '尚未清点', 'conflicting_observations': '清点记录冲突',
                        'matches_observed_total': '与所报数量一致', 'count_mismatch': '数量不符'}
        count_rows = ''.join(
            f'<tr><td>{html.escape(scope["floor_id"])}</td><td>{facades[scope["facade"]]}</td>'
            f'<td>{kinds[kind]}</td><td>{scope[kind]["built_count"]}</td>'
            f'<td>{html.escape(str(scope[kind]["observed_counts"]))}</td>'
            f'<td>{count_labels[scope[kind]["status"]]}</td></tr>'
            for scope in count_report.get('scopes', []) for kind in ('window', 'door'))
        facade_table += ('<h2>逐层逐面外墙门窗清点</h2><p>数量来自所报原图观察；相等不证明位置正确。'
            '未清点、数量不符和冲突均只报告，不阻止交付。</p><table>'
            '<tr><th>楼层</th><th>立面</th><th>类别</th><th>已建</th><th>所报原图数量</th><th>结果</th></tr>'
            + count_rows + '</table>')
        if count_report.get('status') == 'unavailable':
            facade_table += '<p>清点报告暂不可用：' + html.escape(count_report['reason']) + '</p>'
        if count_report.get('unused_observations') or count_report.get('unsupported_exterior_boundaries'):
            facade_table += '<p>部分观察无法绑定当前楼层/立面或原图已变化，或外墙方向未确定；详见 delivery.json 的 facade_counts。</p>'
        height_rows = ''.join(
            f'<tr><td>{html.escape(floor["floor_id"])}</td>'
            f'<td>{html.escape(facades.get(scope.get("facade"), "内部/未确定方向"))}</td>'
            f'<td>{len(scope["actual_opening_ids"])}</td>'
            f'<td>{len(scope["image_evidence_linked_opening_ids"])}</td>'
            f'<td>{html.escape(", ".join(scope["unchecked_height_opening_ids"]) or "—")}</td></tr>'
            for floor in result['height_coverage']['floors']
            for scope in [*floor['facades'], floor['non_facade']])
        height_table = ('<h2>开口高度观察范围</h2><p>按实际开口的当前高度引用统计；'
            '图像依据已关联不代表图意已独立验证。推断/声明仍列入未关联图像范围；'
            '零个已建开口不证明图纸没有开口。</p><table>'
            '<tr><th>楼层</th><th>立面</th><th>已建</th><th>高度图像依据已关联</th>'
            f'<th>高度尚未关联图像依据</th></tr>{height_rows}</table>')
        located = result['located_height_coverage']
        located_labels = {'no_height_observation': '没有当前高度图证',
                          'no_elevation_calibration': '缺少本立面标定，无法核对位置',
                          'whole_image_only': '只有整图引用，未定位到此开口',
                          'outside_source_region': '开口不在高度依据框内',
                          'source_image_changed': '原图已变化'}
        located_rows = ''.join(
            f'<tr><td>{html.escape(row["opening_id"])}</td><td>{html.escape(str(row["facade"]))}</td>'
            f'<td>{html.escape(", ".join(row["floor_ids"]))}</td><td>{row["width_m"]}</td>'
            f'<td>{located_labels.get(row["status"], row["status"])}</td>'
            f'<td>{"同一高度套到不同窗宽，请重点核对" if row["shared_height_across_widths"] else "窗宽与同面其他窗明显不同" if row.get("distinct_width_on_facade") else "—"}</td></tr>'
            for row in located.get('openings', []) if row['status'] != 'covered')
        height_table += ('<h2>逐扇高度依据定位</h2><p>只报告待核范围，不断言高度有误，也不阻止交付。'
                         '需要本立面标定和覆盖该开口的局部高度依据框；整图引用不能证明逐扇核对。</p>'
                         '<table><tr><th>开口</th><th>立面</th><th>楼层</th><th>宽度（米）</th><th>待核原因</th><th>重点</th></tr>'
                         + located_rows + '</table>')
        if located.get('status') == 'unavailable':
            height_table += '<p>定位报告暂不可用：' + html.escape(located['reason']) + '</p>'
        view_labels = {"full_view_returned": "已返回整图", "crop_only_returned": "仅返回局部",
                       "no_direct_view_record": "无直接看图记录"}
        input_rows = ''.join(
            f'<tr><td>{html.escape(row["image"])}</td><td>{view_labels[row["status"]]}</td></tr>'
            for row in result['input_view_status']['images'])
        input_table = ('<h2>本次原图直接查看记录</h2><p>仅统计本次直接看图工具的返回；'
            '其他图像工具、局部模型和前次运行不计入。返回整图不等于已检查全图或读图正确，'
            '也不等于高度已落实到模型。</p><table><tr><th>原图</th><th>返回范围</th></tr>'
            f'{input_rows}</table>' if input_rows else '')
        notes = "".join(f'<li>{html.escape(s)}</li>' for s in result["generation"]["unresolved"])
        notes += "".join(f'<li>{html.escape(row["id"])}：{html.escape(note)}</li>'
                         for row in current_claims["claims"] if row["state"] != "retracted"
                         for note in row["unresolved"])
        notes += "".join(f'<li>继承观察（尚未复核）：{html.escape(note)}</li>'
                         for row in current_claims["inherited_observations"] for note in row["unresolved"])
        claim_labels = {"applied_current": "已应用，当前仍保留", "confirmed_unchanged": "已核对，无需修改",
            "pending_application": "已采纳，尚未关联执行或确认", "partially_satisfied": "仅部分值已落实",
            "changed_since_check": "检查后对象已改变，需复核", "deferred": "暂缓",
            "retracted": "已撤回", "undecided": "待判断"}
        claim_rows = "".join(f'<tr><td>{html.escape(row["id"])}</td><td>{claim_labels[row["state"]]}</td>'
                             f'<td>{html.escape(row["reason"])}</td></tr>' for row in current_claims["claims"])
        superseded = "".join(f'<li>{html.escape(row["before"])} → {html.escape("；".join(row["after"]) or "已撤销")}；'
                             f'{html.escape(row["reason"])}</li>' for row in current_claims["superseded_notes"])
        assumptions = "".join(f'<li>{html.escape(s)}</li>' for s in result["assumptions"])
        counts = result["counts"]
        geometry_status = {"pass":"通过", "warning":"有警告", "severe":"有严重问题"}.get(
            (result.get("source_validation") or {}).get("status"), "未评价")
        deterministic_replay = selection_origin == "developer_selected_deterministic_trace_replay"
        selected = ("开发侧选定的局部轮廓确定性应用" if deterministic_replay else
                    "模型选定" if selection_origin == "agent_selected" else
                    "系统保留的最新候选，模型未显式选定")
        run_status = result["generation_status"]
        run_note = {"completed":"本次模型调用正常结束。", "in_progress":"模型调用尚未结束。",
                    "interrupted":"本次模型调用未正常完成，以下保留已生成候选。"}[run_status["state"]]
        if deterministic_replay:
            run_note = "本次由代码应用已保存的局部观察，未调用模型生成整案；不代表自主冷启动完成。"
        if run_status.get("error"):
            run_note += " " + html.escape(run_status["error"])
        floor_status = result["floor_completeness"]
        if floor_status["complete_building"] is False:
            run_note += " 本稿不完整：尚缺楼层图 " + html.escape(", ".join(floor_status["missing_candidate_images"])) + "。"
        elif floor_status["complete_building"] is True:
            run_note += " 已覆盖预期楼层图；这不证明房间、门窗或高度正确。"
        else:
            run_note += " 未声明可核对的楼层图范围，全楼完整性未判定。"
        feedback = result["source_image_feedback"]
        wall_report = result.get("wall_dimension_report") or {}
        wall_findings = wall_report.get("findings", [])
        wall_rows = "".join(
            f'<tr><td>{html.escape(d["id"])}</td><td>{d["raw_length_m"]}</td>'
            f'<td>{d["representative_length_m"]}</td><td>{d["residual_m"]}</td></tr>'
            for d in wall_report.get("dimensions", []))
        finding_rows = "".join(f'<li>{html.escape(f["dimension_id"])}：{html.escape(f["message"])}</li>'
                               for f in wall_findings)
        calibration_rows = "".join(
            f'<li>{html.escape(row["image"])} / {html.escape(row["floor_id"])}：'
            f'{html.escape(str(warning.get("guidance", warning.get("type"))))}</li>'
            for row in feedback["current_source_projections"] for warning in row.get("calibration_warnings", []))
        host_rows = "".join(
            f'<tr><td>{html.escape(row["image"])} / {html.escape(row["floor_id"])}</td>'
            f'<td>{html.escape(point["marker"])} · {html.escape(point["dimension_id"])}</td>'
            f'<td>{html.escape(", ".join(point["boundary_ids"]))}</td>'
            f'<td>{point["tangential_outside_distance_m"]}</td></tr>'
            for row in feedback["current_source_projections"]
            for point in (row.get("wall_evidence_projection") or {}).get("endpoints", []))
        host_html = (
            '<details><summary>尺寸证据与所引用墙段的位置对照</summary>'
            '<p>图中 W 为已引用墙段，D 的 S/E 为原记录起点/终点。下表距离表示证据点沿墙方向'
            '超出该墙段范围的长度，依赖本图标定；0 不证明归属正确，尺寸引出线也可能合理地落在墙段外。</p>'
            '<table><tr><th>原图 / 楼层</th><th>证据点</th><th>所引用墙段</th>'
            f'<th>沿墙超出范围（米）</th></tr>{host_rows}</table></details>' if host_rows else '')
        evidence_html = (
            '<h2>尺寸与标定的实际反馈</h2><p>以下为工具计算，原始数值及未处理问题不会被模型总结覆盖。'
            '尺寸残差不自动等于建模错误；同墙侧面次序冲突应先核对端点。单位：米。</p>'
            '<table><tr><th>尺寸</th><th>原标注</th><th>换算后代表面距</th><th>模型减换算值</th></tr>'
            f'{wall_rows}</table><ul>{finding_rows}{calibration_rows}</ul>{host_html}'
            if wall_rows or calibration_rows else '')
        current_projection_rows = "".join(
            f'<li>{html.escape(row["image"])} / {html.escape(row["floor_id"])}：'
            f'<a href="{html.escape(row["overlay_image"])}">当前源回叠图</a></li>'
            for row in feedback["current_source_projections"])
        old_projection_rows = "".join(
            f'<li>{html.escape(row["image"])} / {html.escape(row["floor_id"])}：'
            f'{html.escape(row["source_model_sha256"][:12])}</li>'
            for row in feedback["old_source_projections"])
        uncovered_rows = "".join(
            f'<li>{html.escape(row["image"])} / {html.escape(row["floor_id"])}（当前源无该楼层）</li>'
            for row in feedback["registered_calibration_uncovered_floors"])
        unregistered_floor_rows = "".join(
            f'<li>{html.escape(floor_id)}（当前源没有任何登记图面）</li>'
            for floor_id in feedback["floors_without_registered_views"])
        projection_error_rows = "".join(
            f'<li>{html.escape(str(row.get("image")))} / {html.escape(str(row.get("floor_id")))}：'
            f'{html.escape(row["error"])}</li>' for row in feedback["projection_errors"])
        missing_or_failed_rows = uncovered_rows + projection_error_rows
        feedback_html = (
            '<h2>原图回叠反馈</h2><p>标定由模型提供，尚未独立验证；图像已生成不代表已审视或原图保真。</p>'
            f'<p>当前源投影 {len(feedback["current_source_projections"])} 份；旧源投影 '
            f'{len(feedback["old_source_projections"])} 份；登记但当前楼层未覆盖 '
            f'{len(feedback["registered_calibration_uncovered_floors"])} 份；当前源无登记图面楼层 '
            f'{len(feedback["floors_without_registered_views"])} 个。</p>'
            f'<ul>{current_projection_rows or "<li>当前源没有成功的回叠图。</li>"}</ul>'
            f'<details><summary>旧源投影</summary><ul>{old_projection_rows or "<li>无</li>"}</ul></details>'
            f'<details><summary>未覆盖或失败</summary><ul>{missing_or_failed_rows or "<li>无</li>"}'
            f'{unregistered_floor_rows}</ul></details>')
        (self.run / "delivery.html").write_text(
            '<!doctype html><html lang="zh-CN"><meta charset="utf-8">'
            '<title>BIM 候选与实际检查</title><style>body{font:16px system-ui;'
            'max-width:1100px;margin:30px auto;padding:0 16px;line-height:1.6}'
            'table{border-collapse:collapse;width:100%}td,th{padding:8px;border:1px solid #ccc;text-align:left}'
            'iframe{width:100%;height:680px;border:1px solid #ccc}</style>'
            '<h1>BIM 候选与实际检查</h1><p>以下状态来自保存的源模型和回查记录。'
            '几何自洽或观察对应不等于原图保真；未核查和待处理问题见下方记录。</p>'
            f'<p>{run_note}</p>'
            f'<p>{selected}：{html.escape(candidate)}。{counts["spaces"]} 个空间，'
            f'{counts["openings"]} 个已建开口，{counts["unbuilt_openings"]} 个未建开口。'
            f'几何自洽：{geometry_status}；原图保真：未评价。</p>'
            f'<p><a href="{result["viewer"]}">打开模型</a>'
            f' · <a href="{result["source_model"]}">源 BIM</a> · '
            '<a href="delivery.json">检查记录</a></p>'
            '<table><tr><th>楼层</th><th>类别</th><th>已建数量</th><th>原图观察回查</th></tr>'
            f'{rows}</table><p>{len(result["stale_reviews"])} 份旧源回查未用于当前候选。</p>'
            f'{input_table}{facade_table}{height_table}'
            f'<h2>尚未解决</h2><ul>{notes or "<li>模型未填写；仍需结合上表判断未核查范围。</li>"}</ul>'
            f'<details><summary>模型采用的假设</summary><ul>{assumptions}</ul></details>'
            '<h2>当前候选的观察结论</h2><p>以下核对实际参数和宿主是否仍保留，不代表原图判断已经验证。</p>'
            f'<table><tr><th>观察</th><th>当前状态</th><th>依据</th></tr>{claim_rows}</table>'
            f'<details><summary>已替代的说明</summary><ul>{superseded or "<li>无显式替代记录。</li>"}</ul></details>'
            '<details><summary>观察与实际应用</summary><p>采纳、执行成功与原图正确分别判断；'
            '历史应用成功不代表当前候选保留该结果。完整记录见检查记录。</p><pre>'
            + html.escape(json.dumps({"adopted_unapplied": result["adopted_unapplied_claims"],
                                      "applications": result["claim_applications"]}, ensure_ascii=False, indent=2))
            + '</pre></details>'
            f'{feedback_html}'
            f'{evidence_html}'
            f'<iframe title="保存的 BIM 候选" src="{result["viewer"]}"></iframe>'
            '</html>', encoding="utf-8")
        return result

    def inspect_plan(self, draft_id):
        """Read an admitted immutable draft or the explicitly supplied resume plan."""
        if self.readonly:
            raise ValueError("saved plans are available only to the coordinator")
        if draft_id == "resume":
            record = self.manifest.get("plan_recovery")
            if record is None:
                raise ValueError("no saved resume plan was supplied")
            path = self.run / record["frozen_path"]
            expected, image_name = record["raw_sha256"], record["image"]
        else:
            if not isinstance(draft_id, str) or not draft_id.startswith("draft_") or not draft_id[6:].isdigit():
                raise ValueError("choose resume or an existing draft_NNN")
            folder = self.run / "plan_drafts" / draft_id
            record = json.loads((folder / "input.json").read_text())
            path = folder / "plan.json"
            expected, image_name = record["plan_sha256"], record["image"]
        if digest(path) != expected or digest(self.image_path(image_name)) != record["image_sha256"]:
            raise ValueError("saved plan or original image changed")
        return dict(draft_id=draft_id, plan_sha256=expected, image=image_name,
                    declaration=json.loads(path.read_text()))

    def revise_plan(self, draft_id, expected_plan_sha256, operations_json):
        from src.agent.geometry.plan_revision import apply_plan_revision
        from src.agent.geometry.plan_feedback import plan_geometry_feedback, opening_geometry_changes
        parent = self.inspect_plan(draft_id)
        if parent["plan_sha256"] != expected_plan_sha256:
            raise ValueError("stale plan hash; inspect the intended saved draft before revision")
        folder = self.run / "plan_revisions"
        folder.mkdir(exist_ok=True)
        path = folder / f"revision_{len(list(folder.glob('revision_*.json'))) + 1:03d}.json"
        revision = dict(parent_draft_id=draft_id, parent_plan_sha256=expected_plan_sha256,
                        operations_json=operations_json, status="pending")
        dump(path, revision)
        try:
            updated, preservation = apply_plan_revision(parent["declaration"], json.loads(operations_json))
            revision.update(status="declaration_applied", **preservation)
            dump(path, revision)
            # Bind immutable operations and their preservation audit in the new
            # draft's provenance before compiling, including on compiler failure.
            binding = dict(file=str(path.relative_to(self.run)), sha256=digest(path),
                           parent_draft_id=draft_id, parent_plan_sha256=expected_plan_sha256)
            result = self.build_plan(parent["image"], json.dumps(updated, ensure_ascii=False), revision=binding)
        except Exception as error:
            # Once bound, preserve the exact revision file even for internal faults.
            if revision["status"] == "pending":
                revision.update(status="rejected", error=str(error)); dump(path, revision)
            self.log("revise_plan_bim", dict(revision_file=str(path.relative_to(self.run)), error=str(error)))
            raise
        result["plan_revision"] = dict(**binding, unchanged_ids=preservation["unchanged_ids"],
            changed_targets=[dict(field=r["field"], id=r["id"]) for r in preservation["changes"]])
        try:
            saved_plan = json.loads((self.run / result["plan_input"]["plan_file"]).read_text())
            with PILImage.open(self.image_path(parent["image"])) as original:
                changes = opening_geometry_changes(
                    plan_geometry_feedback(parent["declaration"], original.size),
                    plan_geometry_feedback(saved_plan, original.size))
            feedback_path = self.run / result["plan_input"]["plan_file"]
            feedback_path = feedback_path.with_name("opening_changes.json")
            dump(feedback_path, changes)
            result["plan_revision"]["geometry_changes"] = dict(
                file=str(feedback_path.relative_to(self.run)), sha256=digest(feedback_path),
                changed_count=len(changes["changed_openings"]),
                changed_openings=changes["changed_openings"][:24],
                truncated=len(changes["changed_openings"]) > 24,
                unchanged_opening_ids=changes["unchanged_opening_ids"], note=changes["note"])
        except (ValueError, TypeError, KeyError, IndexError) as error:
            result["plan_revision"]["geometry_changes"] = dict(status="unavailable", reason=str(error))
        dump((self.run / result["plan_input"]["plan_file"]).with_name("result.json"), result)
        self.log("revise_plan_bim", dict(candidate=result.get("candidate"),
            source_geometry_ready=result.get("source_geometry_ready"), plan_input=result.get("plan_input"),
            plan_revision=result["plan_revision"], error=result.get("error")))
        return result

    def build_plan(self, image, plan_json, *, revision=None):
        """Preserve a pixel declaration before deterministic compilation or errors."""
        from src.agent.geometry.plan_partition import OpeningHostError, compile_plan_partition
        from src.agent.geometry.plan_draft_view import render_opening_host_failure, render_plan_draft
        from src.agent.geometry.profile_observation_binding import resolve_plan_pixels
        from src.agent.geometry.plan_feedback import resolve_plan_lengths, plan_geometry_feedback, compact_plan_feedback
        image_path = self.image_path(image)
        folder = self.run / "plan_drafts"
        folder.mkdir(exist_ok=True)
        draft = folder / f"draft_{len(list(folder.glob('draft_*'))) + 1:03d}"
        draft.mkdir(exist_ok=False)
        raw_path = draft / "plan.json"
        raw_path.write_text(plan_json, encoding="utf-8")
        record = {"plan_file": str(raw_path.relative_to(self.run)),
                  "plan_sha256": digest(raw_path), "image": image,
                  "image_sha256": digest(image_path)}
        if revision is not None:
            record["revision"] = revision
        dump(draft / "input.json", record)
        input_stage = "parse_json"
        try:
            plan = json.loads(plan_json)
            input_stage = "length_binding"
            plan, length_bindings = resolve_plan_lengths(plan)
            input_stage = "measurement_binding"
            plan, bindings = resolve_plan_pixels(plan, image=image,
                image_sha256=record["image_sha256"], load_profile=self.load_pixel_profile)
        except (ValueError, TypeError, KeyError) as error:
            record["draft_view_errors"] = [{
                "path": "plan_json", "reason": f"{input_stage}: {error}",
            }]
            dump(draft / "input.json", record)
            result = {"status": "error", "error": str(error), "error_stage": input_stage, "plan_input": record,
                      "remaining_seconds": self.remaining_seconds(),
                      "source_geometry_ready": False}
            dump(draft / "result.json", result)
            self.log("build_plan_bim", result)
            return result

        if bindings or length_bindings:
            submitted = draft / "submitted_plan.json"
            submitted.write_bytes(raw_path.read_bytes())
            dump(raw_path, plan)
            binding_path = draft / "measurement_bindings.json"
            dump(binding_path, {"bindings": bindings, "length_bindings": length_bindings, "drawing_fidelity": "not_evaluated",
                "interpretation": "Coordinates resolve caller-selected measurements only; object identity and representative planes remain caller observations."})
            record.update(plan_sha256=digest(raw_path),
                submitted_plan_file=str(submitted.relative_to(self.run)),
                submitted_plan_sha256=digest(submitted),
                measurement_bindings={"file": str(binding_path.relative_to(self.run)),
                    "sha256": digest(binding_path), "count": len(bindings), "length_count": len(length_bindings)})
            dump(draft / "input.json", record)

        try:
            with PILImage.open(image_path) as original:
                dimensions = plan_geometry_feedback(plan, original.size)
            dimensions_path = draft / "geometry_feedback.json"
            dump(dimensions_path, dimensions)
            record["geometry_feedback"] = dict(file=str(dimensions_path.relative_to(self.run)),
                sha256=digest(dimensions_path), **compact_plan_feedback(dimensions))
        except (ValueError, TypeError, KeyError, IndexError) as error:
            record["geometry_feedback"] = dict(status="unavailable", reason=str(error))

        # Report-only comparison of the original's ink with this declaration, also for
        # drafts that fail to compile (run75/83/86/94 left drawn dividers out; run91/93/94
        # placed doors on solid wall).
        try:
            from src.agent.geometry.plan_drawing_differences import compact_differences, drawing_differences
            with PILImage.open(image_path) as original:
                differences = drawing_differences(original, plan, image_name=image,
                    image_sha256=record["image_sha256"], plan_sha256=record["plan_sha256"])
            differences_path = draft / "drawing_differences.json"
            dump(differences_path, differences)
            difference_reply = dict(file=str(differences_path.relative_to(self.run)),
                sha256=digest(differences_path), **compact_differences(differences))
        except (ValueError, TypeError, KeyError, IndexError) as error:
            difference_reply = dict(status="unavailable", reason=str(error))

        try:
            with PILImage.open(image_path) as original:
                preview, preview_metadata = render_plan_draft(
                    original, plan, image_name=image,
                    image_sha256=record["image_sha256"],
                    plan_file=record["plan_file"], plan_sha256=record["plan_sha256"],
                )
            preview_path = draft / "draft_view.png"
            preview.save(preview_path)
            preview_metadata["preview"] = {
                "image_file": str(preview_path.relative_to(self.run)),
                "image_sha256": digest(preview_path),
            }
            metadata_path = draft / "draft_view.json"
            dump(metadata_path, preview_metadata)
            record["draft_view"] = {
                **preview_metadata["preview"],
                "metadata_file": str(metadata_path.relative_to(self.run)),
                "metadata_sha256": digest(metadata_path),
                "draft_only": True,
                "drawing_fidelity": "not_evaluated",
                "source_geometry_ready": False,
                "unrenderable_count": len(preview_metadata["unrenderable"]),
                "unrenderable": preview_metadata["unrenderable"],
            }
        except Exception as error:
            record.setdefault("draft_view_errors", []).append({
                "path": "draft_view", "reason": str(error),
            })
        dump(draft / "input.json", record)

        try:
            with PILImage.open(image_path) as original:
                proposal, metadata = compile_plan_partition(
                    plan, image_size=original.size, image_name=image)
        except (ValueError, TypeError, KeyError) as error:
            if isinstance(error, OpeningHostError):
                try:
                    with PILImage.open(image_path) as original:
                        local_view, local_metadata = render_opening_host_failure(
                            original, plan, opening_id=error.opening_id,
                            p1_pixel=error.p1_pixel, p2_pixel=error.p2_pixel,
                            image_name=image, image_sha256=record["image_sha256"],
                            plan_file=record["plan_file"], plan_sha256=record["plan_sha256"],
                        )
                    local_path = draft / "opening_host_failure.png"
                    local_view.save(local_path)
                    metadata_path = draft / "opening_host_failure.json"
                    dump(metadata_path, local_metadata)
                    record["host_failure_view"] = {
                        "image_file": str(local_path.relative_to(self.run)),
                        "image_sha256": digest(local_path),
                        "metadata_file": str(metadata_path.relative_to(self.run)),
                        "metadata_sha256": digest(metadata_path),
                        "opening_id": error.opening_id,
                        "p1_original_pixels": error.p1_pixel,
                        "p2_original_pixels": error.p2_pixel,
                        "metadata": local_metadata,
                    }
                except Exception as feedback_error:
                    record.setdefault("host_failure_view_errors", []).append(str(feedback_error))
                dump(draft / "input.json", record)
            result = {"status": "error", "error": str(error), "drawing_differences": difference_reply,
                      "plan_input": record, "remaining_seconds": self.remaining_seconds(),
                      "source_geometry_ready": False}
            dump(draft / "result.json", result)
            self.log("build_plan_bim", result)
            return result
        dump(draft / "compilation.json", metadata)
        record.update(compilation_file=str((draft / "compilation.json").relative_to(self.run)),
                      compilation_sha256=digest(draft / "compilation.json"))
        result = self.build(proposal, action="build_plan_bim", plan_input=record,
                            calibration={key: plan[key] for key in
                                         ("floor_id", "x_anchors", "y_anchors", "basis")})
        if "candidate" not in result:
            result.update(plan_input=record, source_geometry_ready=False,
                          remaining_seconds=self.remaining_seconds())
            self.log("build_plan_bim", result)
        result["drawing_differences"] = difference_reply
        dump(draft / "result.json", result)
        return result

    def assemble_plans(self, floors_json):
        """Recompile bound pixel drafts and combine their explicitly placed floors."""
        from src.agent.geometry.plan_assembly import assemble_plan_proposals
        from src.agent.geometry.plan_partition import compile_plan_partition
        if self.readonly:
            raise ValueError("floor assembly is available only to the coordinator")
        floors = json.loads(floors_json)
        if not isinstance(floors, list) or not 2 <= len(floors) <= 32:
            raise ValueError("supply 2–32 explicit floor declarations")
        items, bindings, calibrations = [], [], []
        for row in floors:
            required = {"draft_id", "expected_plan_sha256", "floor_id", "z_floor", "evidence"}
            if not isinstance(row, dict) or set(row) != required:
                raise ValueError(f"each floor requires exactly {sorted(required)}")
            if not isinstance(row["evidence"], str) or not row["evidence"].strip():
                raise ValueError("each floor needs image evidence or an explicit placement assumption")
            saved = self.inspect_plan(row["draft_id"])
            if saved["plan_sha256"] != row["expected_plan_sha256"]:
                raise ValueError("stale plan hash; inspect each intended draft before assembly")
            plan, image = saved["declaration"], saved["image"]
            with PILImage.open(self.image_path(image)) as original:
                proposal, compilation = compile_plan_partition(plan, image_size=original.size, image_name=image)
            items.append(dict(proposal=proposal, floor_id=row["floor_id"], z_floor=row["z_floor"],
                              source_ref=row["evidence"]))
            bindings.append(dict(**row, image=image, image_sha256=digest(self.image_path(image)),
                                 original_floor_id=plan["floor_id"], original_z_floor=plan["z_floor"],
                                 ceiling_height=plan["ceiling_height"], compilation=compilation))
            calibrations.append(dict(image=image, floor_id=row["floor_id"],
                **{key: plan[key] for key in ("x_anchors", "y_anchors", "basis")}))
        proposal = assemble_plan_proposals(items)
        folder = self.run / "plan_assemblies"
        folder.mkdir(exist_ok=True)
        path = folder / f"assembly_{len(list(folder.glob('assembly_*.json'))) + 1:03d}.json"
        dump(path, {"floors": bindings, "operation": "namespace_ids_and_translate_z_only",
                    "height_policy": "preserve_declared_heights; revise a draft explicitly to change them"})
        binding = {"file": str(path.relative_to(self.run)), "sha256": digest(path)}
        result = self.build(proposal, action="assemble_plan_bim", plan_assembly=binding,
                            assembly_calibrations=calibrations)
        # Assembly keeps each draft's XY, so each draft's saved comparison still applies.
        from src.agent.geometry.plan_drawing_differences import compact_differences
        differences = {}
        for row in bindings:
            saved = self.run / "plan_drafts" / row["draft_id"] / "drawing_differences.json"
            if saved.is_file():
                differences[row["floor_id"]] = dict(draft_id=row["draft_id"],
                    **compact_differences(json.loads(saved.read_text())))
        if differences:
            result["drawing_differences"] = differences
        self.log("assemble_plan_bim", {"assembly": binding, "candidate": result.get("candidate"),
                                      "error": result.get("error")})
        return result

    def build(self, proposal, *, action="build_bim", parent=None, operations=None,
              plan_input=None, calibration=None, claim_application=None,
              plan_assembly=None, assembly_calibrations=None):
        from src.agent.execution.source_proposal import export_source_proposal
        if isinstance(proposal, dict) and 'mesh_frame' in proposal:
            from src.agent.geometry.mesh_bim_frame import validate_mesh_frame
            frame = validate_mesh_frame(proposal['mesh_frame'])
            if frame['mesh_sha256'] != self.manifest.get('mesh_input', {}).get('sha256'):
                raise ValueError('candidate mesh_frame must refer to the admitted original mesh')
        budget = self.candidate_budget()
        index = budget["used"] + 1
        if budget["remaining"] == 0:
            return {"error": "candidate budget exhausted; report saved partial results",
                    "candidate_budget": budget, "remaining_seconds": self.remaining_seconds()}
        candidate = f"candidate_{index:02d}"
        provenance = {"input_manifest_sha256": digest(self.run/"inputs.json"),
                      "mode": self.manifest.get("input_mode", "original_images_agent_experiment"),
                      "generator": f"{self.manifest.get('provider', 'claude')} subscription tool loop"}
        if parent is not None:
            provenance.update(parent_candidate=parent,
                              parent_proposal_sha256=digest(self.candidate_path(parent)/"proposal.json"))
        if plan_input is not None:
            provenance["plan_input"] = plan_input
        if claim_application is not None:
            provenance["claim_application"] = claim_application
        if plan_assembly is not None:
            provenance["plan_assembly"] = plan_assembly
        report = export_source_proposal(proposal, self.run/candidate, provenance=provenance)
        if operations is not None:
            dump(self.run/candidate/"operations.json", operations)
        result = {"candidate": candidate, "remaining_seconds": self.remaining_seconds(), **report,
                  "candidate_budget": self.candidate_budget(),
                  "input_view_status": self.input_view_status()}
        if plan_assembly is not None:
            result["plan_assembly"] = plan_assembly
        if plan_input is not None:
            result["plan_input"] = plan_input
            result["plan_compilation"] = json.loads(
                (self.run / plan_input["compilation_file"]).read_text())
        source_path = self.run / candidate / "source_model.json"
        if source_path.exists():
            from src.agent.geometry.opening_review import opening_inventory
            from src.agent.roles import room_use_review
            source = json.loads(source_path.read_text())
            result["room_use_review"] = room_use_review(source, include_next_action=False)
            result["located_height_coverage"] = self.located_heights(candidate)
            result["facade_counts"] = self.facade_counts(candidate)
            result["opening_inventory"] = opening_inventory(source)
            result["opening_review"] = "not_reviewed; compare this inventory with distinct drawing marks"
            if calibration is not None:
                self._save_calibration(candidate=candidate, image=plan_input["image"],
                                       metadata=report, **calibration)
            for registered in assembly_calibrations or []:
                self._save_calibration(candidate=candidate, metadata=report, **registered)
            projections, errors = self.project_registered_calibrations(candidate, action)
            result["source_image_projections"] = projections
            result["projection_errors"] = errors
            result["source_plan_views"], result["source_plan_errors"] = [], []
            source = json.loads(source_path.read_text())
            for floor in source["floors"]:
                try:
                    _, metadata = self.plan_view(candidate, floor["id"])
                    result["source_plan_views"].append(metadata)
                except Exception as error:
                    result["source_plan_errors"].append({"candidate": candidate,
                        "floor_id": floor["id"], "error": str(error)})
        self.log(action, result)
        return result

    def plan_view(self, candidate, floor_id):
        from src.agent.geometry.source_plan_view import render_source_plan
        path = self.candidate_path(candidate)
        source = json.loads((path / "source_model.json").read_text())
        pic, metadata = render_source_plan(source, floor_id)
        # Retain the existing plan filename for ordinary floor names. A digest
        # suffix separates names that would otherwise alias after slash removal.
        stem = "plan_" + floor_id.replace("/", "_").replace("\\", "_")
        if "/" in floor_id or "\\" in floor_id:
            stem += "_" + hashlib.sha256(floor_id.encode()).hexdigest()[:12]
        image_path = path / (stem + ".png")
        pic.save(image_path)
        metadata.update(candidate=candidate, plan_image=str(image_path.relative_to(self.run)))
        dump(path / (stem + ".json"), metadata)
        return Image(data=image_path.read_bytes(), format="png"), metadata

    def image_path(self, name):
        from scripts.tool_scripts.bim_agent_feedback import resolve_image_name
        name = resolve_image_name(self.manifest["images"], name)
        path = self.run / "images" / name
        if digest(path) != self.manifest["images"][name]["sha256"]:
            raise ValueError("input image changed")
        return path

    def load_pixel_profile(self, profile_id):
        """Load only a saved profile from this run; consumers bind image and axis."""
        if not isinstance(profile_id, str) or not re.fullmatch(r"profile_\d{3,}", profile_id):
            raise ValueError("choose an existing profile_id returned by view_pixel_profile")
        folder = (self.run / "pixel_profiles").resolve()
        path = folder / f"{profile_id}.json"
        if not path.is_file() or path.resolve().parent != folder:
            raise ValueError("choose an existing profile_id returned by view_pixel_profile")
        raw = path.read_bytes()
        return {"record": json.loads(raw), "sha256": hashlib.sha256(raw).hexdigest()}

    def compare_facade_spans(self, plan_image, elevation_image, observations_json,
                             plan_axis="y", elevation_axis="x", ambiguity_tolerance_m=0.05):
        """Persist caller observations bound to admitted originals; never change BIM."""
        from src.agent.geometry.facade_span_comparison import compare
        from src.agent.geometry.profile_observation_binding import resolve_observations
        def reject_constant(value):
            raise ValueError(f"observations_json contains non-finite constant {value}")

        observations = json.loads(observations_json, parse_constant=reject_constant)
        sources = {}
        for label, name, axis in (("plan", plan_image, plan_axis),
                                  ("elevation", elevation_image, elevation_axis)):
            if axis not in {"x", "y"}:
                raise ValueError("image axis must be x or y")
            path = self.image_path(name)
            with PILImage.open(path) as pic:
                size = list(pic.size)
            sources[label] = {"image": name, "sha256": digest(path),
                              "size": size, "axis": axis}

        def load_profile(profile_id):
            # resolve_observations validates the ID before calling this loader.
            path = self.run / "pixel_profiles" / f"{profile_id}.json"
            if not path.is_file() or path.resolve().parent != (self.run / "pixel_profiles"):
                raise ValueError("choose an existing profile_id returned by view_pixel_profile")
            raw = path.read_bytes()
            return {"record": json.loads(raw, parse_constant=reject_constant),
                    "sha256": hashlib.sha256(raw).hexdigest()}

        resolved, bindings = resolve_observations(observations, load_profile=load_profile,
                                                   views=sources)
        result = compare(resolved, ambiguity_tolerance_m)
        for label, source in sources.items():
            bound = source["size"][0 if source["axis"] == "x" else 1]
            if any(not 0 <= anchor[0] <= bound
                   for anchor in result["normalized_inputs"][label]["axis_anchors"]):
                raise ValueError(f"{label} axis anchors lie outside original image bounds")
        folder = self.run / "facade_comparisons"
        folder.mkdir(exist_ok=True)
        index = 1
        while (folder / f"comparison_{index:03d}.json").exists():
            index += 1
        path = folder / f"comparison_{index:03d}.json"
        result.update(original_images=sources, observations=resolved,
                      submitted_observations=observations, measurement_bindings=bindings,
                      evidence_status="caller_observations_not_independently_verified",
                      record=str(path.relative_to(self.run)))
        with path.open("x") as output:
            json.dump(result, output, ensure_ascii=False, indent=2, allow_nan=False)
            output.write("\n")
        self.log("compare_facade_spans", {"record": result["record"],
                                         "direction_separation": result["direction_separation"]})
        return result

    def _calibration_records(self):
        """Return immutable explicit calibration records in registration order."""
        folder = self.run / "overlay_calibrations"
        records = []
        for path in sorted(folder.glob("calibration_*.json")) if folder.is_dir() else []:
            record = json.loads(path.read_text())
            if not isinstance(record, dict):
                raise ValueError(f"invalid overlay calibration record: {path.name}")
            records.append((path, record))
        return records

    def registered_calibrations(self):
        """The latest explicit calibration for each exact original-image/floor pair."""
        latest = {}
        for path, record in self._calibration_records():
            image = record.get("image")
            floor_id = record.get("floor_id")
            if not isinstance(image, str) or not isinstance(floor_id, str):
                raise ValueError(f"invalid overlay calibration identity: {path.name}")
            latest[(image, floor_id)] = (path, record)
        return list(latest.values())

    def check_space_relations(self, candidate, image, floor_id, observations_json):
        from src.agent.geometry.source_space_relations import review_space_relations
        self.image_path(image)
        calibrations = [(path, row) for path, row in self.registered_calibrations()
                        if (row['image'], row['floor_id']) == (image, floor_id)]
        if not calibrations:
            raise ValueError('register this image/floor calibration with overlay_candidate or build_plan_bim first')
        path, calibration = calibrations[0]
        if calibration['image_sha256'] != self.manifest['images'][image]['sha256']:
            raise ValueError('calibration original image changed')
        source = json.loads((self.candidate_path(candidate) / 'source_model.json').read_text())
        report = review_space_relations(source, floor_id=floor_id,
            image_size=self.manifest['images'][image]['size'],
            x_anchors=calibration['x_anchors'], y_anchors=calibration['y_anchors'],
            observations=json.loads(observations_json))
        folder = self.run / 'space_relation_reviews'
        folder.mkdir(exist_ok=True)
        target = folder / f'review_{len(list(folder.glob("review_*.json"))) + 1:03d}.json'
        result = {**report, 'candidate': candidate, 'image': image,
                  'image_sha256': self.manifest['images'][image]['sha256'],
                  'calibration_file': str(path.relative_to(self.run)),
                  'calibration_sha256': digest(path),
                  'review_file': str(target.relative_to(self.run)),
                  'remaining_seconds': self.remaining_seconds()}
        dump(target, result)
        self.log('check_source_space_relation', result)
        return result

    def space_relation_status(self, source):
        """Keep sampled expectations tied to the current source and calibration."""
        calibrations = {(row['image'], row['floor_id']): digest(path)
                        for path, row in self.registered_calibrations()}
        latest, stale_count = {}, 0
        for path in sorted((self.run / 'space_relation_reviews').glob('review_*.json')):
            report = json.loads(path.read_text())
            pair = (report['image'], report['floor_id'])
            if (report['source_model_sha256'] != source['source_model_sha256']
                    or report['calibration_sha256'] != calibrations.get(pair)
                    or report['image_sha256'] != self.manifest['images'].get(pair[0], {}).get('sha256')):
                stale_count += 1
                continue
            self.image_path(pair[0])
            for row in report['observations']:
                latest[(*pair, row['id'])] = {**row, 'review_file': str(path.relative_to(self.run))}
        conflicts = [row for row in latest.values() if row['consistency'] == 'conflicts_with_supplied_expectation']
        unassessed = sum(row['consistency'] == 'not_assessed' for row in latest.values())
        status = ('not_reviewed' if not latest else 'observations_require_follow_up' if conflicts or unassessed
                  else 'consistent_with_supplied_samples')
        return {'status': status, 'sample_count': len(latest), 'conflict_count': len(conflicts),
                'unassessed_count': unassessed, 'stale_review_count': stale_count,
                'conflicts': [{'id': row['id'], 'expected': row['expected'],
                               'actual_relation': row['actual_relation'], 'review_file': row['review_file']}
                              for row in conflicts],
                'coverage': 'caller_selected_point_pairs_only', 'drawing_fidelity': 'not_evaluated'}

    def _save_calibration(self, *, candidate, image, floor_id, x_anchors, y_anchors, basis, metadata):
        """Append an explicit calibration. Later records supersede only the same pair."""
        folder = self.run / "overlay_calibrations"
        folder.mkdir(exist_ok=True)
        index = len(list(folder.glob("calibration_*.json"))) + 1
        path = folder / f"calibration_{index:03d}.json"
        record = {
            "schema_version": "source_overlay_calibration_v1",
            "calibration_id": path.stem,
            "image": image,
            "floor_id": floor_id,
            "image_sha256": self.manifest["images"][image]["sha256"],
            "x_anchors": x_anchors,
            "y_anchors": y_anchors,
            "basis": basis,
            "registered_by_candidate": candidate,
            "registered_source_model_sha256": metadata["source_model_sha256"],
            "calibration_basis": "caller_supplied_not_independently_verified",
            "calibration_unverified": True,
        }
        dump(path, record)
        return path, record

    def _save_overlay(self, pic, metadata, *, box=None):
        """Persist a full immutable projection and make the corresponding tool view."""
        folder = self.run / "image_overlays"
        folder.mkdir(exist_ok=True)
        stem = f"overlay_{len(list(folder.glob('overlay_*.json'))) + 1:03d}"
        original_size = list(pic.size)
        region = box or [0, 0, pic.width, pic.height]
        if box is not None:
            x0, y0, x1, y1 = box
            if not (0 <= x0 < x1 <= pic.width and 0 <= y0 < y1 <= pic.height):
                raise ValueError("crop outside original image bounds")
        # The stored overlay is full resolution.  The returned image follows the
        # same bounded presentation convention as view_image.
        pic.save(folder / f"{stem}.png")
        presented = pic.crop(region)
        presented.thumbnail((1600, 1600))
        metadata.update(
            overlay_image=f"image_overlays/{stem}.png",
            original_size=original_size,
            box_original_pixels=region,
            returned_size=list(presented.size),
            original_pixels_per_returned_pixel=[
                (region[2] - region[0]) / presented.width,
                (region[3] - region[1]) / presented.height,
            ],
            remaining_seconds=self.remaining_seconds(),
        )
        dump(folder / f"{stem}.json", metadata)
        data = io.BytesIO()
        presented.save(data, "PNG")
        return Image(data=data.getvalue(), format="png"), metadata

    def project_overlay(self, candidate, image, floor_id, x_anchors, y_anchors, basis, *,
                        trigger_action, box=None, calibration=None, automatic=False):
        """Render and persist one projection from an immutable saved source BIM."""
        from src.agent.geometry.source_image_overlay import render_source_overlay
        path = self.candidate_path(candidate)
        source = json.loads((path / "source_model.json").read_text())
        image_path = self.image_path(image)
        with PILImage.open(image_path) as raw:
            pic, metadata = render_source_overlay(source, raw, floor_id=floor_id,
                x_anchors=x_anchors, y_anchors=y_anchors, basis=basis, image_name=image)
        metadata.update(
            candidate=candidate,
            image=image,
            image_sha256=self.manifest["images"][image]["sha256"],
            trigger_action=trigger_action,
            automatic_projection=automatic,
        )
        if calibration is not None:
            calibration_path, calibration_record = calibration
            metadata["reused_calibration"] = {
                "calibration_id": calibration_record["calibration_id"],
                "calibration_file": str(calibration_path.relative_to(self.run)),
                "registered_by_candidate": calibration_record["registered_by_candidate"],
                "registered_source_model_sha256": calibration_record["registered_source_model_sha256"],
                "image_sha256": calibration_record["image_sha256"],
                "x_anchors": calibration_record["x_anchors"],
                "y_anchors": calibration_record["y_anchors"],
                "basis": calibration_record["basis"],
            }
        return self._save_overlay(pic, metadata, box=box)

    def project_registered_calibrations(self, candidate, action):
        """Reuse only caller-registered frames; projection failures preserve the BIM."""
        projections = []
        errors = []
        try:
            calibrations = self.registered_calibrations()
        except Exception as error:
            calibrations = []
            errors.append({"candidate": candidate, "trigger_action": action,
                           "error": f"could not load registered calibrations: {error}"})
        for calibration in calibrations:
            calibration_path, record = calibration
            error_context = {
                "candidate": candidate,
                "trigger_action": action,
                "image": record.get("image"),
                "floor_id": record.get("floor_id"),
                "calibration_file": str(calibration_path.relative_to(self.run)),
            }
            try:
                _, metadata = self.project_overlay(
                    candidate, record["image"], record["floor_id"], record["x_anchors"],
                    record["y_anchors"], record["basis"], trigger_action=action,
                    calibration=calibration, automatic=True)
                projections.append(metadata)
            except Exception as error:
                errors.append({**error_context, "error": str(error)})
        if errors:
            dump(self.candidate_path(candidate) / "projection_errors.json", {
                "candidate": candidate,
                "trigger_action": action,
                "projection_errors": errors,
            })
        return projections, errors

    def overlay_image(self, metadata):
        """Load only a projection created by this toolkit for MCP image content."""
        relative = metadata.get("overlay_image")
        if not isinstance(relative, str) or not relative.startswith("image_overlays/"):
            raise ValueError("invalid saved overlay reference")
        path = (self.run / relative).resolve()
        folder = (self.run / "image_overlays").resolve()
        if not path.is_file() or folder not in path.parents:
            raise ValueError("saved overlay is unavailable")
        with PILImage.open(path) as raw:
            pic = raw.convert("RGB")
            pic.thumbnail((1600, 1600))
            data = io.BytesIO()
            pic.save(data, "PNG")
        return Image(data=data.getvalue(), format="png")

    def _delivery_projection_status(self, candidate, source):
        """Describe stored projection evidence without treating it as a visual verdict."""
        source_hash = source.get("source_model_sha256")
        folder = self.run / "image_overlays"
        projections = []
        for path in sorted(folder.glob("overlay_*.json")) if folder.is_dir() else []:
            record = json.loads(path.read_text())
            if isinstance(record, dict) and record.get("mode") == "source_image_overlay":
                projections.append(record)
        current = [row for row in projections
                   if row.get("candidate") == candidate and row.get("source_model_sha256") == source_hash]
        old = [row for row in projections if row.get("source_model_sha256") != source_hash]
        floor_ids = {row.get("id") for row in source.get("floors", []) if isinstance(row, dict)}
        uncovered = []
        try:
            calibrations = self.registered_calibrations()
            calibration_load_errors = []
        except Exception as error:
            calibrations = []
            calibration_load_errors = [{"candidate": candidate, "trigger_action": "finish_bim",
                                        "error": f"could not load registered calibrations: {error}"}]
        registered_floor_ids = {calibration["floor_id"] for _, calibration in calibrations}
        for calibration_path, calibration in calibrations:
            if calibration["floor_id"] not in floor_ids:
                uncovered.append({
                    "image": calibration["image"], "floor_id": calibration["floor_id"],
                    "calibration_file": str(calibration_path.relative_to(self.run)),
                })
        error_path = self.candidate_path(candidate) / "projection_errors.json"
        errors = json.loads(error_path.read_text()).get("projection_errors", []) if error_path.is_file() else []
        errors = [*errors, *calibration_load_errors]
        fields = ("image", "floor_id", "overlay_image", "source_model_sha256", "trigger_action",
                  "automatic_projection", "reused_calibration", "anchors", "basis", "image_sha256")
        def compact(row):
            return {**{field: row[field] for field in fields if field in row},
                    "calibration_warnings": row.get("scale", {}).get("warnings", []),
                    "wall_evidence_projection": row.get("wall_evidence_projection")}
        return {
            "current_source_projections": [compact(row) for row in current],
            "old_source_projections": [compact(row) for row in old],
            "registered_calibration_uncovered_floors": uncovered,
            "floors_without_registered_views": sorted(floor_id for floor_id in floor_ids
                                                       if floor_id not in registered_floor_ids),
            "projection_errors": errors,
            "calibration_independently_verified": False,
            "drawing_fidelity": "not_evaluated",
        }

    def view_claim_evidence(self, claim_id, source_index=0, display_scale=1.0):
        """Render a saved reference, bound to its original bytes; never certify it."""
        if self.readonly:
            raise ValueError("saved claims are available only to the coordinator")
        row = self.claims().read(claim_id)
        if (not isinstance(source_index, int) or isinstance(source_index, bool)
                or not 0 <= source_index < len(row["sources"])):
            raise ValueError("source_index must select an existing zero-based claim source")
        ref = row["sources"][source_index]
        if digest(self.image_path(ref["image"])) != ref["sha256"]:
            raise ValueError("claim original image changed")
        # Enclose fractional references instead of rounding away narrow regions.
        left, top, right, bottom = ref["box"]
        box = [math.floor(left), math.floor(top), math.ceil(right), math.ceil(bottom)]
        picture, raw_metadata = self.view(ref["image"], box, coordinate_grid=False,
                                          display_scale=display_scale)
        metadata = json.loads(raw_metadata)
        if metadata["image_sha256"] != ref["sha256"] or metadata["original_size"] != ref["size"]:
            raise ValueError("claim original image changed")
        metadata.update(claim_id=claim_id, source_index=source_index,
                        claimed_box_original_pixels=ref["box"],
                        verification="not_independently_verified",
                        interpretation="Inspect the actual crop for the cited labels, endpoints and object context. "
                                       "If misplaced, record a corrected claim and retract the obsolete one.")
        self.log("view_claim_evidence", metadata)
        return CallToolResult(content=[picture.to_image_content(),
            TextContent(type="text", text=json.dumps(metadata))], structuredContent=metadata)

    def read_image_view(self, view_id):
        if not isinstance(view_id, str) or not re.fullmatch(r"view_\d{4,}", view_id):
            raise ValueError("choose a saved view_NNNN from view_image")
        path = self.run / "image_views" / f"{view_id}.json"
        if not path.is_file():
            raise ValueError("choose an existing view_NNNN from this run")
        raw = path.read_bytes()
        metadata = json.loads(raw)
        if digest(self.image_path(metadata["name"])) != metadata["image_sha256"]:
            raise ValueError("view original image changed")
        with PILImage.open(self.image_path(metadata["name"])) as image:
            if list(image.size) != metadata["original_size"]:
                raise ValueError("view original size changed")
        return {"record": metadata, "sha256": hashlib.sha256(raw).hexdigest()}

    def elevation_view(self, candidate, facade, image="", horizontal_anchors=None, z_anchors=None, basis=""):
        """Pair an explicitly chosen full original with the current source elevation."""
        from mcp.server.fastmcp import Image
        from src.agent.geometry.source_elevation_view import render_source_elevation
        path = self.candidate_path(candidate)
        source = json.loads((path / "source_model.json").read_text())
        if image:
            self.image_path(image)  # Validate before recording a comparison.
        calibrated = horizontal_anchors is not None or z_anchors is not None or bool(basis)
        if calibrated:
            if not image or horizontal_anchors is None or z_anchors is None:
                raise ValueError("calibrated elevation requires image, horizontal_anchors, z_anchors and basis")
            from src.agent.geometry.source_elevation_overlay import render_elevation_overlay
            with PILImage.open(self.image_path(image)) as original:
                pic, metadata = render_elevation_overlay(source, original, facade=facade,
                    horizontal_anchors=horizontal_anchors, z_anchors=z_anchors, basis=basis)
            metadata.update(candidate=candidate, image=image, image_sha256=digest(self.image_path(image)))
            source_picture, metadata = self._save_overlay(pic, metadata)
            image_path = self.run / metadata["overlay_image"]
        else:
            pic, metadata = render_source_elevation(source, facade)
            image_path = path / f"elevation_{facade}.png"
            pic.save(image_path)
            data = io.BytesIO()
            pic.save(data, "PNG")
            source_picture = Image(data=data.getvalue(), format="png")
        metadata.update(candidate=candidate, elevation_image=str(image_path.relative_to(self.run)),
                        elevation_image_sha256=digest(image_path))
        pictures = []
        if image:
            original, original_metadata = self.view(image, coordinate_grid=False)
            original_metadata = json.loads(original_metadata)
            pictures.append(original)
            metadata["original_view"] = original_metadata
            metadata["comparison"] = {
                "image_order": ["full_original", "calibrated_source_elevation" if calibrated else "source_elevation"],
                "image_facade_binding": "caller_selected_not_verified",
                "pixel_alignment": ("caller-calibrated original frame; both returned images have the same scale"
                                    if calibrated else "none; the two images have independent scales and frames"),
                "review": "Match visible opening shapes to source IDs and their above-floor/absolute height intervals. "
                          "Use the full dimension chain and opening outline together; an ordinary-window height "
                          "does not establish other opening families. Reopen a clean crop with view_image when needed. "
                          "Revise only supported discrepancies and recheck the resulting source.",
            }
        pictures.append(source_picture)
        dump(path / f"elevation_{facade}.json", metadata)
        folder = self.run / "elevation_reviews"
        folder.mkdir(exist_ok=True)
        # Exclusive records retain repeated comparisons even when the same facade
        # is later paired with a different original. They are observations, not passes.
        index = len(list(folder.glob("review_*.json"))) + 1
        while True:
            target = folder / f"review_{index:04d}.json"
            metadata["review_file"] = str(target.relative_to(self.run))
            try:
                with target.open("x") as saved:
                    saved.write(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n")
                break
            except FileExistsError:
                index += 1
        self.log("view_elevation_candidate", metadata)
        return pictures, metadata

    def view(self, name, box=None, coordinate_grid=True, display_scale=1.0):
        from mcp.server.fastmcp import Image
        if (not isinstance(display_scale, (int, float)) or isinstance(display_scale, bool)
                or not math.isfinite(display_scale)):
            raise ValueError("display_scale must be a finite number; allowed range is 1 through 8")
        # GLM sm24 requested 0.7x. Preserve intent within the display-only limits.
        requested_scale = display_scale
        display_scale = max(1, min(8, display_scale))
        name = self.image_path(name).name
        with PILImage.open(self.image_path(name)) as raw:
            pic = raw.convert("RGB")
            original_size = list(pic.size)
            region = box or [0, 0, pic.width, pic.height]
            if box is not None:
                x0,y0,x1,y1 = box
                if not (0 <= x0 < x1 <= pic.width and 0 <= y0 < y1 <= pic.height):
                    raise ValueError("crop outside original image bounds")
                pic = pic.crop(box)
            crop_size = pic.size
            if display_scale == 1:
                # Preserve the existing default presentation, including its
                # downsampling behaviour for large full-image views.
                pic.thumbnail((1600,1600))
            else:
                # Calculate the capped target before resizing so a high requested
                # scale never creates a large temporary bitmap.
                actual_scale = min(float(display_scale), 1600 / max(crop_size))
                target_size = tuple(max(1, round(length * actual_scale)) for length in crop_size)
                pic = pic.resize(target_size, PILImage.Resampling.NEAREST)
            grid = {"shown": False}
            if coordinate_grid:
                pic, grid = coordinate_grid_view(pic, region)
            data = io.BytesIO(); pic.save(data, "PNG")
        actual_scale = [pic.width / crop_size[0], pic.height / crop_size[1]]
        metadata = {"name": name, "image_sha256": digest(self.image_path(name)),
                    "original_size": original_size, "coordinate_grid": grid,
                    "box_original_pixels": region, "returned_size": list(pic.size),
                    "display_scale_requested": requested_scale,
                    "display_scale_used": display_scale,
                    "display_scale_actual": actual_scale,
                    "original_pixels_per_returned_pixel": [
                        (region[2] - region[0]) / pic.width,
                        (region[3] - region[1]) / pic.height],
                    "coordinate_note": ("Grid labels show ORIGINAL pixels. Original pixel = crop origin + returned "
                                        "pixel * original_pixels_per_returned_pixel. Use ORIGINAL pixels for the next "
                                        "crop or measurement.")}
        if requested_scale != display_scale:
            metadata["display_scale_note"] = f"Requested {requested_scale}x; clamped to allowed [1, 8]: {display_scale}x."
        if display_scale > 1 and min(actual_scale) < display_scale - 0.05:
            # run94 asked 1.5-2x for 1100-1500 px strips and got 1.08-1.43x without noticing.
            metadata["magnification_note"] = (
                f"Returned images are at most 1600 px on their long side, so this {crop_size[0]}x{crop_size[1]} px "
                f"box was enlarged only {min(actual_scale):.2f}x; choose a smaller box to magnify more.")
        metadata["remaining_seconds"] = self.remaining_seconds()
        # Small immutable view records let callers reuse the actual returned region.
        # Exclusive creation also keeps simultaneous readers from overwriting it.
        folder = self.run / "image_views"
        folder.mkdir(exist_ok=True)
        index = len(list(folder.glob("view_*.json"))) + 1
        while True:
            metadata["view_id"] = f"view_{index:04d}"
            metadata["source_reference"] = {"view_id": metadata["view_id"]}
            metadata["returned_png_sha256"] = hashlib.sha256(data.getvalue()).hexdigest()
            path = folder / f"{metadata['view_id']}.json"
            raw = (json.dumps(metadata, ensure_ascii=False, sort_keys=True) + "\n").encode()
            try:
                with path.open("xb") as saved:
                    saved.write(raw)
                break
            except FileExistsError:
                index += 1
        metadata["view_record_sha256"] = hashlib.sha256(raw).hexdigest()
        self.log("view_image", metadata)
        return [Image(data=data.getvalue(), format="png"), json.dumps(metadata)]

    def plan_wall_support(self, draft_id, rgb, tolerance=70, radius_pixels=6, minimum_ink_pixels=1):
        """Review exactly one saved declaration; never mutate or approve it."""
        from src.agent.geometry.plan_wall_support import measure_plan_wall_support
        if self.readonly:
            raise ValueError("saved plan drafts are available only to the coordinator")
        if (not isinstance(draft_id, str) or not draft_id.startswith("draft_")
                or not draft_id[6:].isdigit()):
            raise ValueError("choose a saved draft_NNN from build_plan_bim")
        folder = self.run / "plan_drafts" / draft_id
        if not (folder / "input.json").is_file():
            raise ValueError("choose an existing saved plan draft")
        admitted = json.loads((folder / "input.json").read_text())
        plan_path = folder / "plan.json"
        if digest(plan_path) != admitted["plan_sha256"]:
            raise ValueError("saved plan changed")
        image_path = self.image_path(admitted["image"])
        if digest(image_path) != admitted["image_sha256"]:
            raise ValueError("draft original image changed")
        compilation_path = folder / "compilation.json"
        compilation = None
        if compilation_path.is_file():
            saved = json.loads((folder / "result.json").read_text())["plan_input"]
            if (saved["plan_sha256"] != admitted["plan_sha256"]
                    or digest(compilation_path) != saved["compilation_sha256"]):
                raise ValueError("saved compilation changed")
            compilation = json.loads(compilation_path.read_text())
        with PILImage.open(image_path) as original:
            pic, result = measure_plan_wall_support(original, json.loads(plan_path.read_text()),
                rgb=rgb, tolerance=tolerance, radius_pixels=radius_pixels,
                minimum_ink_pixels=minimum_ink_pixels,
                spaces=compilation["space_mapping"] if compilation else None)
        target = self.run / "plan_wall_support"
        target.mkdir(exist_ok=True)
        stem = f"support_{len(list(target.glob('support_*.json'))) + 1:03d}"
        pic.save(target / f"{stem}.png")
        result.update(draft_id=draft_id, plan_sha256=admitted["plan_sha256"],
                      image=admitted["image"], image_sha256=admitted["image_sha256"],
                      support_image=f"plan_wall_support/{stem}.png",
                      support_record=f"plan_wall_support/{stem}.json",
                      support_image_sha256=digest(target / f"{stem}.png"),
                      remaining_seconds=self.remaining_seconds())
        returned = pic.copy()
        returned.thumbnail((1600, 1600))
        data = io.BytesIO()
        returned.save(data, "PNG")
        result["returned_size"] = list(returned.size)
        result["original_combined_size"] = list(pic.size)
        dump(target / f"{stem}.json", result)
        self.log("view_plan_wall_support", {"draft_id": draft_id, "record": result["support_record"],
                                             "review_interval_count": len(result["review_intervals"])})
        return [Image(data=data.getvalue(), format="png"), json.dumps(result)]

    def profile(self, name, box, axis, rgb, tolerance):
        import numpy as np
        with PILImage.open(self.image_path(name)) as raw:
            x0,y0,x1,y1 = box
            if not (0 <= x0 < x1 <= raw.width and 0 <= y0 < y1 <= raw.height):
                raise ValueError("box outside original image bounds")
            pixels = np.asarray(raw.convert("RGB").crop(box)).astype(float)
        if len(rgb) != 3 or not all(0 <= c <= 255 for c in rgb) or not 0 <= tolerance <= 442:
            raise ValueError("RGB in 0..255 and distance tolerance in 0..442 required")
        mask = np.linalg.norm(pixels - np.asarray(rgb), axis=2) <= tolerance
        if axis not in {"x", "y"}:
            raise ValueError("axis must be x or y")
        counts = mask.sum(axis=0 if axis == "x" else 1)
        offset = x0 if axis == "x" else y0
        # Return runs of positive support plus maxima, without naming objects.
        runs = []; start = None
        for i, count in enumerate([*counts, 0]):
            if count > 0 and start is None: start = i
            if count == 0 and start is not None:
                peak = start + int(counts[start:i].argmax())
                runs.append({"pixels": [start+offset, i-1+offset], "peak": peak+offset,
                             "max_count": int(counts[peak]),
                             "support_peaks": _profile_support_peaks(counts[start:i], start + offset)})
                start = None
        result = {"axis": axis, "runs": runs, "matching_pixels": int(mask.sum()),
                  "name": name, "box_original_pixels": list(box),
                  "support_length": mask.shape[0] if axis == "x" else mask.shape[1],
                  "coordinate_system": "original image pixels; interval endpoints inclusive",
                  "evidence_note": "pixels spans any positive color support, including connected "
                      "lines, text and arrow tips; its ends are not measured dimension or object endpoints. "
                      "peak is only the FIRST global maximum in the run. support_peaks lists every "
                      "positive local maximum plateau with its count, including weaker peaks, in "
                      "original coordinates; no smoothing, threshold or endpoint selection is applied. "
                      "A plateau is higher than both adjacent counts (zero outside the run). "
                      "Peaks can include noise and do not identify ticks, walls or openings. Inspect "
                      "the original crop or use view_pixel_profile with the same input image name and "
                      "a chosen min_fraction before adopting coordinates."}
        diagnostic = _empty_profile_diagnostics(
            pixels, rgb, counts, 1, mask.shape[0] if axis == "x" else mask.shape[1])
        if diagnostic is not None:
            result["empty_filter_diagnostics"] = diagnostic
        self.log("pixel_profile", {"name": name, "box": box, "rgb": rgb,
                                   "tolerance": tolerance, "result": result})
        return result

    def view_profile(self, name, box, axis, rgb, tolerance, min_fraction):
        """Return a checkable profile table and image without assigning semantics."""
        import numpy as np
        if (not isinstance(min_fraction, (int, float)) or isinstance(min_fraction, bool)
                or not 0 < min_fraction <= 1):
            raise ValueError("min_fraction must be a number greater than 0 and at most 1")
        with PILImage.open(self.image_path(name)) as raw:
            x0, y0, x1, y1 = box
            if not (0 <= x0 < x1 <= raw.width and 0 <= y0 < y1 <= raw.height):
                raise ValueError("box outside original image bounds")
            crop = raw.convert("RGB").crop(box)
            original_size = raw.size
            pixels = np.asarray(crop).astype(float)
        if len(rgb) != 3 or not all(0 <= c <= 255 for c in rgb) or not 0 <= tolerance <= 442:
            raise ValueError("RGB in 0..255 and distance tolerance in 0..442 required")
        if axis not in {"x", "y"}:
            raise ValueError("axis must be x or y")
        mask = np.linalg.norm(pixels - np.asarray(rgb), axis=2) <= tolerance
        counts, minimum_count, support_length, runs = _profile_axis(mask, box, axis, min_fraction)
        projection_offset = x0 if axis == "x" else y0
        support_offset = y0 if axis == "x" else x0
        candidates = [{"id": f"C{i + 1:02d}", **row} for i, row in enumerate(runs)]
        other_axis = "y" if axis == "x" else "x"
        other_counts, other_minimum, other_length, other_runs = _profile_axis(mask, box, other_axis, min_fraction)
        edge_support = {}
        for edge, support, offset in (("left", mask[:, 0], y0), ("right", mask[:, -1], y0),
                                      ("top", mask[0, :], x0), ("bottom", mask[-1, :], x0)):
            edge_support[edge] = [[lo + offset, hi + offset] for lo, hi in _inclusive_runs(support)]

        # Keep the original crop untouched on the left.  The right panel is a
        # separate exact mask view with candidate bands and peaks labelled.
        panel_pixels = np.full((crop.height, crop.width, 3), 255, dtype=np.uint8)
        panel_pixels[mask] = (150, 150, 150)
        panel = PILImage.fromarray(panel_pixels, "RGB")
        draw = ImageDraw.Draw(panel)
        for candidate in candidates:
            lo = candidate["pixels"][0] - projection_offset
            hi = candidate["pixels"][1] - projection_offset
            peak = candidate["peak"] - projection_offset
            if axis == "x":
                draw.rectangle((lo, 0, hi, crop.height - 1), outline=(220, 0, 120), width=1)
                for support_lo, support_hi in candidate["support_intervals_at_peak"]:
                    draw.line((peak, support_lo - support_offset,
                               peak, support_hi - support_offset), fill=(0, 110, 220), width=1)
                label_xy = (lo + 1, 1)
            else:
                draw.rectangle((0, lo, crop.width - 1, hi), outline=(220, 0, 120), width=1)
                for support_lo, support_hi in candidate["support_intervals_at_peak"]:
                    draw.line((support_lo - support_offset, peak,
                               support_hi - support_offset, peak), fill=(0, 110, 220), width=1)
                label_xy = (1, lo + 1)
            draw.text(label_xy, candidate["id"], fill="black")
        combined = PILImage.new("RGB", (crop.width * 2 + 3, crop.height), "white")
        combined.paste(crop, (0, 0))
        combined.paste(panel, (crop.width + 3, 0))
        ImageDraw.Draw(combined).rectangle((crop.width, 0, crop.width + 2, crop.height - 1), fill="black")

        folder = self.run / "pixel_profiles"
        folder.mkdir(exist_ok=True)
        stem = f"profile_{len(list(folder.glob('profile_*.json'))) + 1:03d}"
        image_path = folder / f"{stem}.png"
        record_path = folder / f"{stem}.json"
        combined.save(image_path)
        result = {
            "name": name,
            "profile_id": stem,
            "image_sha256": self.manifest["images"][name]["sha256"],
            "axis": axis,
            "box_original_pixels": box,
            "rgb": rgb,
            "tolerance": tolerance,
            "min_fraction": float(min_fraction),
            "minimum_count": minimum_count,
            "support_length": support_length,
            "matching_pixels": int(mask.sum()),
            "candidates": candidates,
            "threshold_excluded_support": _profile_excluded_support(
                counts, projection_offset, minimum_count, support_length),
            "cross_axis_profile": {
                "axis": other_axis, "min_fraction": float(min_fraction),
                "minimum_count": other_minimum, "support_length": other_length,
                "runs": other_runs,
                "threshold_excluded_support": _profile_excluded_support(
                    other_counts, support_offset, other_minimum, other_length),
                "note": "Same exact mask and fraction, measured along the other axis. "
                        "Compare long traces with local junction peaks; neither is a wall label. "
                        "For bindable C IDs on this axis, request a profile using this axis.",
            },
            "crop_context": {
                "edge_support_intervals": edge_support,
                "suggested_view_box": [max(0, x0 - 32), max(0, y0 - 32),
                                       min(original_size[0], x1 + 32), min(original_size[1], y1 + 32)],
                "note": "Edge intervals are matching pixels on the crop border (right/bottom are exclusive "
                        "box limits, so samples are at right-1/bottom-1). A crop edge is not an object endpoint. "
                        "The suggested box is only an initial 32px context expansion; inspect further as needed "
                        "to establish both endpoints and adjoining space boundaries. No continuation is inferred.",
            },
            "profile_image": str(image_path.relative_to(self.run)),
            "profile_record": str(record_path.relative_to(self.run)),
            "profile_image_sha256": digest(image_path),
            "panel_layout": {
                "original_crop_combined_pixels": [0, 0, crop.width, crop.height],
                "mask_panel_combined_pixels": [crop.width + 3, 0, combined.width, crop.height],
                "separator_width": 3,
            },
            "panel_note": "Left is the untouched original crop. Right is an exact color-distance mask: magenta outlines candidate bands; blue marks only actual support at the peak coordinate. Marks are coordinate references, not entities. Right-panel local coordinates correspond to the same original crop after removing its combined-image offset.",
            "evidence_note": "Support intervals are measured only at each candidate peak. They do not prove a whole band is continuous or identify a wall. Filtered or empty results do not prove an object is absent.",
            "remaining_seconds": self.remaining_seconds(),
        }
        diagnostic = _empty_profile_diagnostics(pixels, rgb, counts, minimum_count, support_length)
        if diagnostic is not None:
            result["empty_filter_diagnostics"] = diagnostic
        returned = combined.copy()
        returned.thumbnail((1600, 1600))
        data = io.BytesIO()
        returned.save(data, "PNG")
        result["returned_size"] = list(returned.size)
        result["original_pixels_per_returned_pixel"] = [
            combined.width / returned.width, combined.height / returned.height]
        result["display_note"] = "For a returned-image point (rx, ry), first multiply by original_pixels_per_returned_pixel to obtain full combined-image coordinates (fx, fy). On the left, original image coordinates are (box_left + fx, box_top + fy). On the right, subtract mask_panel_combined_pixels[0] from fx before adding box_left. Prefer candidates and support intervals, which already use original-image coordinates."
        dump(record_path, result)
        self.log("view_pixel_profile", {"name": name, "box": box, "rgb": rgb,
                                        "tolerance": tolerance, "min_fraction": min_fraction,
                                        "result": result})
        return [Image(data=data.getvalue(), format="png"), json.dumps(result)]


    def pixel_region_overview(self, name, background_rgb, tolerance, min_pixels, max_regions, include_border):
        from src.agent.geometry.pixel_region_overview import render_pixel_region_overview
        with PILImage.open(self.image_path(name)) as original:
            picture, record = render_pixel_region_overview(original, background_rgb=background_rgb,
                tolerance=tolerance, min_pixels=min_pixels, max_regions=max_regions, include_border=include_border)
        folder = self.run / "pixel_region_overviews"
        folder.mkdir(exist_ok=True)
        overview_id = f"overview_{len(list(folder.glob('overview_*.json'))) + 1:03d}"
        picture.save(folder / f"{overview_id}.png")
        record.update(overview_id=overview_id, name=name, image_sha256=digest(self.image_path(name)),
                      overview_image=f"pixel_region_overviews/{overview_id}.png",
                      remaining_seconds=self.remaining_seconds())
        dump(folder / f"{overview_id}.json", record)
        self.log("view_pixel_region_overview", record)
        buffer = io.BytesIO(); picture.save(buffer, "PNG")
        return [Image(data=buffer.getvalue(), format="png"), json.dumps(record)]

    def pixel_region(self, name, seed_pixel, background_rgb, tolerance, simplify_pixels):
        from src.agent.geometry.pixel_region import render_pixel_region
        with PILImage.open(self.image_path(name)) as original:
            picture, record = render_pixel_region(original, seed_pixel=seed_pixel,
                background_rgb=background_rgb, tolerance=tolerance, simplify_pixels=simplify_pixels)
        folder = self.run / "pixel_regions"
        folder.mkdir(exist_ok=True)
        region_id = f"region_{len(list(folder.glob('region_*.json'))) + 1:03d}"
        picture.save(folder / f"{region_id}.png")
        record.update(region_id=region_id, name=name, image_sha256=digest(self.image_path(name)),
                      region_image=f"pixel_regions/{region_id}.png", remaining_seconds=self.remaining_seconds())
        dump(folder / f"{region_id}.json", record)
        self.log("view_pixel_region", record)
        buffer = io.BytesIO(); picture.save(buffer, "PNG")
        return [Image(data=buffer.getvalue(), format="png"), json.dumps(record)]

    def preview_trace(self, name, polygon_pixels, openings, x_anchors, y_anchors, basis):
        from src.agent.geometry.space_trace import render_space_trace
        with PILImage.open(self.image_path(name)) as original:
            picture, result = render_space_trace(original, polygon_pixels=polygon_pixels,
                openings=openings, x_anchors=x_anchors, y_anchors=y_anchors, basis=basis)
        folder = self.run / "space_traces"
        folder.mkdir(exist_ok=True)
        trace = f"trace_{len(list(folder.glob('trace_*.json'))) + 1:03d}"
        picture.save(folder / f"{trace}.png")
        result.update(trace_id=trace, name=name, image_sha256=digest(self.image_path(name)),
                      trace_image=f"space_traces/{trace}.png", remaining_seconds=self.remaining_seconds())
        dump(folder / f"{trace}.json", result)
        self.log("preview_space_trace", result)
        buffer = io.BytesIO(); picture.save(buffer, "PNG")
        return [Image(data=buffer.getvalue(), format="png"), json.dumps(result)]

    def view_trace(self, trace_id):
        allowed = {p.stem for p in (self.run / "space_traces").glob("trace_*.json")}
        if trace_id not in allowed:
            raise ValueError("unknown trace_id")
        record = json.loads((self.run / "space_traces" / f"{trace_id}.json").read_text())
        if digest(self.image_path(record["name"])) != record["image_sha256"]:
            raise ValueError("trace original image changed")
        self.log("view_space_trace", {"trace_id": trace_id})
        return [Image(data=(self.run / "space_traces" / f"{trace_id}.png").read_bytes(), format="png"), json.dumps(record)]

    def select_trace(self, trace_id):
        allowed = {p.stem for p in (self.run / "space_traces").glob("trace_*.json")}
        if trace_id not in allowed:
            raise ValueError("unknown trace_id; first preview_space_trace")
        result = json.loads((self.run / "space_traces" / f"{trace_id}.json").read_text())
        if not result["geometrically_executable"]:
            raise ValueError("trace has geometry errors; revise the contour/aperture endpoints first")
        if digest(self.image_path(result["name"])) != result["image_sha256"]:
            raise ValueError("trace original image changed")
        selection = {"trace_id": trace_id, "trace_sha256": digest(self.run / "space_traces" / f"{trace_id}.json"),
                     "drawing_fidelity": "not_evaluated", "selection_origin": "model_selected"}
        dump(self.run / "trace_selection.json", selection)
        self.log("select_space_trace", selection)
        return selection


def serve(run: Path, readonly=False, *, enabled_only=False):
    from mcp.server.fastmcp import Image
    from scripts.tool_scripts.bim_agent_feedback import FeedbackMCP
    toolkit = Toolkit(run, readonly)
    server = FeedbackMCP(toolkit, "bim", log_level="WARNING")
    from scripts.tool_scripts.bim_agent_mesh import register_mesh_tools
    register_mesh_tools(server, toolkit)
    from scripts.tool_scripts.bim_agent_inference import register_inference_tools
    register_inference_tools(server, toolkit)

    @server.tool()
    def get_bim_reference(topic: str) -> dict:
        """Topics: plan_partition, plan_assembly, geometry, parametric (build formats);
        edits, wall_dimensions (revise_bim operations); claims; opening_review;
        facade_correspondence; room_types (role catalog); naming (public names);
        reconstruction (the drawing method already in the system prompt);
        partial_inference (mesh evidence, architectural hypotheses, assembly, source review).
        Generic formats and interfaces, not case observations or answers.
        """
        if topic not in REFERENCES:
            raise ValueError("unknown topic; choose " + ", ".join(REFERENCES))
        toolkit.log("get_bim_reference", {"topic": topic})
        return {"topic": topic, "reference": REFERENCES[topic],
                "remaining_seconds": toolkit.remaining_seconds()}

    @server.tool()
    def inputs() -> dict:
        """List admitted original images, native mesh, building declaration and scope."""
        toolkit.log("inputs", {})
        return {**toolkit.manifest, "input_view_status": toolkit.input_view_status(),
                "candidate_budget": toolkit.candidate_budget(),
                "remaining_seconds": toolkit.remaining_seconds()}

    @server.tool()
    def view_image(name: ImageFilename, box: list[int] | None = None, coordinate_grid: bool = True,
                   display_scale: float = 1.0):
        """name is an input image filename from inputs(). View all or crop [left,top,right,bottom] in ORIGINAL pixels.
        Returned images are at most 1600 px on their long side; grid labels keep original
        coordinates. display_scale enlarges up to that limit, so a box whose longest side
        is under ~500 px can be shown 3x or more; coordinates stay original pixels.
        Use coordinate_grid=false for unmarked evidence; stored originals are unchanged.
        Returned view_id can be used directly in claim sources or replace_claim_sources;
        do not copy crop coordinates again when citing exactly this view.
        """
        return toolkit.view(name, box, coordinate_grid, display_scale)

    @server.tool()
    def pixel_profile(name: ImageFilename, box: list[int], axis: str,
                      rgb: list[int], tolerance: float = 70) -> dict:
        """name is an input image filename from inputs(), not a measurement label. Measure colored ink runs along x or y.
        You select RGB/tolerance; results have no wall/door semantic labels.
        """
        return toolkit.profile(name, box, axis, rgb, tolerance)

    @server.tool()
    def view_pixel_profile(name: ImageFilename, box: list[int], axis: str,
                           rgb: list[int], tolerance: float = 70,
                           min_fraction: float = 0.1):
        """name is an input image filename from inputs(), not a measurement label. Show a color profile in ORIGINAL pixels.
        axis=x searches x coordinates and reports unbridged y support at each
        peak; axis=y does the converse. min_fraction is the required matching
        share along the other axis. Results are pixel evidence, not object labels.
        cross_axis_profile measures the SAME mask in the other direction;
        crop_context flags cut ink and suggests a wider original-image view.
        Use profile_id and candidate IDs in compare_facade_spans coordinate slots
        to adopt measured coordinates without copying numbers.
        """
        return toolkit.view_profile(name, box, axis, rgb, tolerance, min_fraction)

    @server.tool()
    def view_pixel_region_overview(name: ImageFilename, background_rgb: list[int], tolerance: float = 60,
                                   min_pixels: int = 500, max_regions: int = 40,
                                   include_border: bool = False):
        """Locate numbered colour-connected candidates in the full original image.
        background_rgb is the target colour: either ink (e.g. a frame) or a
        clear area's background. Compare the labelled overview to the original,
        then pass a returned ORIGINAL-pixel seed to view_pixel_region.
        Small ink strokes may need a lower min_pixels than clear floor regions.
        Area/border filters and truncation are reported. Candidates can include
        furniture, dimension marks or connected spaces; IDs are not object labels.
        """
        return toolkit.pixel_region_overview(name, background_rgb, tolerance, min_pixels, max_regions, include_border)

    @server.tool()
    def view_pixel_region(name: ImageFilename, seed_pixel: list[int], background_rgb: list[int],
                          tolerance: float = 60, simplify_pixels: float = 1.5):
        """Display the complete 4-connected target-colour region at a selected pixel.
        background_rgb names the target colour, including ink or clear floor.
        Choose a seed on that colour, preferably an overview candidate's seed.
        For clear floor choose away from furniture; for frames choose on the ink.
        Returns a non-semantic contour and half-open bbox, NOT a room/aperture.
        One physical frame may contain disconnected pieces; touching same-colour
        marks may merge. simplify_pixels=0 keeps the exact pixel outline.
        Check the original surrounding wall and jambs before interpreting it.
        All points and seed coordinates refer to the ORIGINAL image.
        """
        return toolkit.pixel_region(name, seed_pixel, background_rgb, tolerance, simplify_pixels)

    @server.tool()
    def preview_space_trace(name: ImageFilename, polygon_pixels: list[list[float]], openings: list[dict],
                            x_anchors: list[list[float]], y_anchors: list[list[float]], basis: str):
        """Draw your COMPLETE ordered room contour on its original image before building.
        Include interior and exterior boundaries; close logically across apertures.
        openings = [{id,p1:[x,y],p2:[x,y]}] uses the two wall jambs, not hinge-to-leaf-tip.
        All positions are ORIGINAL pixels; each axis has two [pixel,world_metres] anchors.
        Use a declared representative wall plane; do not trace both faces as two walls.
        Returns clean/marked images, geometry errors and mapped points, no source mutation.
        """
        return toolkit.preview_trace(name, polygon_pixels, openings, x_anchors, y_anchors, basis)

    @server.tool()
    def view_space_trace(trace_id: str):
        """View the actual saved clean/marked image and coordinates for a local trace."""
        return toolkit.view_trace(trace_id)

    @server.tool()
    def select_space_trace(trace_id: str) -> dict:
        """Select a previewed local trace after visually checking its actual overlay.
        This selects an observation; it is not a BIM or a drawing-fidelity pass.
        """
        return toolkit.select_trace(trace_id)

    @server.tool()
    def map_dimension_chain(lengths: list[float], unit: str = "mm",
                            origin_m: float = 0.0, direction: int = 1,
                            expected_total: float | None = None) -> dict:
        """Accumulate observed dimension labels into ordered world-metre spans.
        lengths and expected_total use unit mm or m; origin_m is always metres.
        direction -1 walks from a known high coordinate toward lower coordinates.
        No OCR or semantic validation: retain evidence for labels and orientation.
        """
        from src.agent.geometry.dimension_chain import map_dimension_chain as calculate
        result = calculate(lengths, unit=unit, origin_m=origin_m,
                           direction=direction, expected_total=expected_total)
        toolkit.log("map_dimension_chain", {"lengths": lengths, "result": result})
        return result

    @server.tool()
    def compare_facade_spans(plan_image: ImageFilename, elevation_image: ImageFilename, observations_json: str,
                             plan_axis: str = "y", elevation_axis: str = "x",
                             ambiguity_tolerance_m: float = 0.05) -> dict:
        """Compare complete independently observed opening lists in BOTH axis directions.
        Exact original image names and original pixel coordinates only. JSON has plan
        and elevation, each with axis_anchors [[pixel,0],[pixel,L_metres]] and openings
        [{"id":"observed_id","pixels":[start,end]}]. Retain types/evidence as extra fields.
        Any pixel slot may instead be {"profile":"profile_001","candidate":"C01",
        "at":"peak"}; at=peak/start/end, default peak. Uses saved measurement pixels
        directly, checks image and axis, and preserves the binding. No numeric offset.
        Read facade_correspondence for an example and limitations. No automatic OCR,
        direction acceptance, missing-opening repair or source mutation.
        """
        return toolkit.compare_facade_spans(plan_image, elevation_image, observations_json,
                                             plan_axis, elevation_axis, ambiguity_tolerance_m)

    def candidate_result(result) -> CallToolResult:
        """Keep JSON structured output while attaching newly generated feedback views."""
        # Put drawing differences, then actionable dimensions/edits, ahead of the large inventories.
        result = {**{k: result[k] for k in ("drawing_differences", "plan_revision", "plan_input") if k in result}, **result}
        content = []
        draft_view = result.get("plan_input", {}).get("draft_view")
        if not result.get("source_geometry_ready") and draft_view:
            try:
                content.append(Image(data=(toolkit.run / draft_view["image_file"]).read_bytes(),
                                     format="png").to_image_content())
            except Exception as error:
                result.setdefault("plan_input", {}).setdefault("draft_view_errors", []).append({
                    "path": draft_view.get("image_file"),
                    "reason": f"MCP result packaging failed: {error}",
                })
        host_failure_view = result.get("plan_input", {}).get("host_failure_view")
        if not result.get("source_geometry_ready") and host_failure_view:
            try:
                content.append(Image(data=(toolkit.run / host_failure_view["image_file"]).read_bytes(),
                                     format="png").to_image_content())
            except Exception as error:
                result.setdefault("plan_input", {}).setdefault("host_failure_view_errors", []).append({
                    "path": host_failure_view.get("image_file"),
                    "reason": f"MCP result packaging failed: {error}",
                })
        for metadata in result.get("source_image_projections", []):
            try:
                content.append(toolkit.overlay_image(metadata).to_image_content())
            except Exception as error:
                result.setdefault("projection_errors", []).append({
                    "candidate": result.get("candidate"), "trigger_action": "mcp_result_packaging",
                    "image": metadata.get("image"), "floor_id": metadata.get("floor_id"),
                    "overlay_image": metadata.get("overlay_image"), "error": str(error),
                })
        for metadata in result.get("source_plan_views", []):
            try:
                content.append(Image(data=(toolkit.run / metadata["plan_image"]).read_bytes(),
                                     format="png").to_image_content())
            except Exception as error:
                result.setdefault("source_plan_errors", []).append({
                    "candidate": result.get("candidate"), "floor_id": metadata.get("floor_id"),
                    "trigger_action": "mcp_result_packaging", "error": str(error)})
        content.append(TextContent(type="text", text=json.dumps(result, ensure_ascii=False)))
        return CallToolResult(content=content, structuredContent=result)

    @server.tool()
    def map_pixels(points: list[list[float]], x_anchors: list[list[float]],
                   y_anchors: list[list[float]]) -> dict:
        """Convert selected original pixel points to metres with two anchors per axis.
        Each anchor is [pixel_position, world_metres]. Y normally has negative
        slope. Anchors must come from your observed dimensions or explicit assumption;
        this tool does arithmetic and does not establish the drawing scale for you.
        """
        import math
        def fit(anchors):
            if len(anchors)!=2 or any(len(a)!=2 for a in anchors):
                raise ValueError("exactly two [pixel, metre] anchors per axis")
            if not all(math.isfinite(v) for a in anchors for v in a):
                raise ValueError("anchors must be finite")
            (p0,w0),(p1,w1)=anchors
            if p0==p1 or w0==w1: raise ValueError("distinct anchors required")
            slope=(w1-w0)/(p1-p0)
            return slope,w0-slope*p0
        ax,bx=fit(x_anchors); ay,by=fit(y_anchors)
        if any(len(p)!=2 or not all(math.isfinite(v) for v in p) for p in points):
            raise ValueError("points must be finite [x,y]")
        result={"world_points":[[round(ax*x+bx,6),round(ay*y+by,6)] for x,y in points],
                "metres_per_pixel":[ax,ay]}
        toolkit.log("map_pixels",{"points":points,"x_anchors":x_anchors,
                                  "y_anchors":y_anchors,"result":result})
        return result

    if not readonly:
        @server.tool()
        def inspect_plan_draft(draft_id: str) -> dict:
            """Read a saved draft_NNN or resume declaration, its immutable hash and every
            drawing_differences item recorded for that draft. Use the returned hash with
            revise_plan_bim for local edits.
            """
            saved = toolkit.inspect_plan(draft_id)
            report = toolkit.run / "plan_drafts" / str(draft_id) / "drawing_differences.json"
            if draft_id != "resume" and report.is_file():
                data = json.loads(report.read_text())
                if data.get("plan_sha256") == saved["plan_sha256"]:
                    saved["drawing_differences"] = data
            return saved

        @server.tool()
        def revise_plan_bim(draft_id: str, expected_plan_sha256: str, operations_json: str) -> CallToolResult:
            """Locally edit saved pixel wall/opening/seed declarations by ID.
            Read plan_partition reference for operations. Untouched declarations
            stay exact; compiler and source/overlay feedback run normally. This
            rebuilds ONE floor and may change room topology, never auto-fixes it.
            """
            return candidate_result(toolkit.revise_plan(draft_id, expected_plan_sha256, operations_json))

        @server.tool()
        def view_plan_wall_support(draft_id: str, rgb: list[int], tolerance: float = 70,
                                   radius_pixels: int = 6, minimum_ink_pixels: int = 1):
            """Check complete partition paths from a saved build_plan_bim draft_NNN.
            Choose wall RGB and strip radius from the original. Returns clean/marked
            original, exact supported and unsupported intervals, declared apertures
            separately, and proposed adjacent rooms if compilation exists. Gaps are
            prompts to reobserve, not missing-wall verdicts. No BIM change or approval.
            Supports failed drafts too. Coordinates are original pixels, never GT.
            """
            return toolkit.plan_wall_support(draft_id, rgb, tolerance, radius_pixels, minimum_ink_pixels)

        def claim_result(row) -> CallToolResult:
            if row.get("observation_type") == "facade_count":
                return CallToolResult(content=[TextContent(type="text", text=json.dumps(row))], structuredContent=row)
            content, previews = [], []
            for index in range(min(3, len(row["sources"]))):
                result = toolkit.view_claim_evidence(row["id"], index)
                content.extend(result.content)
                previews.append(result.structuredContent)
            reply = {**row, "evidence_previews": previews,
                     "unpreviewed_source_indices": list(range(3, len(row["sources"])))}
            # run94 claim_0001 applied a 3.6 m chain to 3 m storey windows on three facades
            # and two widths; show those facts beside the claim without judging them.
            try:
                from src.agent.execution.bim_claim_facts import claim_facts
                reply = {"facts": claim_facts(row, toolkit.claims().candidate(row["claim"]["candidate"])[0]), **reply}
            except (OSError, ValueError, KeyError, TypeError) as error:
                reply["facts"] = {"status": "unavailable", "reason": str(error)}
            content.append(TextContent(type="text", text=json.dumps(reply)))
            return CallToolResult(content=content, structuredContent=reply)

        @server.tool()
        def record_claim(claim_json: str) -> CallToolResult:
            """Record located values for a candidate, or one image/floor/facade count.
            observation_type=facade_count can precede BIM; read get_bim_reference('claims').
            Geometric claims return up to three clean source crops; view_claim_evidence
            shows more. Counts are observations, not geometry edits or verified image truth.
            """
            return claim_result(toolkit.record_claim(claim_json))

        @server.tool()
        def replace_claim_sources(claim_id: str, view_ids: list[str], reason: str) -> CallToolResult:
            """Replace wrong claim regions using actual view_image IDs, without retyping values.
            Creates a new immutable claim on the SAME saved candidate, preserving objects,
            value definitions, targets, basis and unresolved items; replaces sources/reason.
            Retracts the old claim explicitly, returns new crops. New claim is unadopted:
            decide_claim then confirm_claims/revise_bim is still required. No BIM change.
            Full original views are valid; seeing a view does not certify interpretation.
            """
            return claim_result(toolkit.replace_claim_sources(claim_id, view_ids, reason))

        @server.tool()
        def view_claim_evidence(claim_id: str, source_index: int = 0,
                                display_scale: float = 1.0) -> CallToolResult:
            """View one actual saved claim region, using its original image hash.
            source_index is zero-based; display_scale 1..8 enlarges tiny annotations.
            Fractional boxes are enclosed in whole pixels and both boxes are reported.
            This shows evidence; it neither adopts nor independently verifies the claim.
            """
            return toolkit.view_claim_evidence(claim_id, source_index, display_scale)

        @server.tool()
        def decide_claim(claim_id: str, disposition: str, reason: str) -> dict:
            """Choose adopted/deferred/retracted; adoption does not apply geometry."""
            return toolkit.decide_claim(claim_id, disposition, reason)

        @server.tool()
        def claim_status(candidate: str | None = None) -> dict:
            """With candidate, project checks onto its actual ancestry and geometry.
            Without candidate, read complete run history. Historical application alone
            is not current applicability or drawing truth.
            """
            if candidate is not None:
                from src.agent.execution.bim_claim_state import project
                return project(toolkit.claims(), candidate)
            return toolkit.claims().status()

        @server.tool()
        def confirm_claims(candidate: str, operations_json: str) -> dict:
            """Check adopted claim references against unchanged saved parameters.
            Use the same update_window/update_opening/move_shared_wall operations as
            revise_bim. Every parameter must be a claim reference. Rejects any actual
            geometric change; saves a confirmation without generating a new candidate.
            """
            return toolkit.confirm_claims(candidate, operations_json)

        @server.tool()
        def check_wall_dimensions(candidate: str, references_json: str = "", dimensions_json: str = "",
                                  include_inventory: bool = False, floor_id: str | None = None,
                                  offset: int = 0, limit: int = 30) -> dict:
            """List real wall hosts or convert explicit wall-face dimensions without changing geometry.
            See get_bim_reference("wall_dimensions") for the input format. Empty strings
            reuse saved evidence. Persist new evidence separately via revise_bim.
            Inventory is included only when no references exist or explicitly requested.
            Its wall list is paged (limit 1..50); floor_id narrows the inventory only,
            without changing explicit reference/dimension conversion. Read next_offset
            until null when you need the full selected inventory.
            """
            from src.agent.geometry.wall_reference import resolve_wall_references, convert_wall_dimensions
            path = toolkit.candidate_path(candidate)
            source = json.loads((path / "source_model.json").read_text())
            proposal = json.loads((path / "proposal.json").read_text())
            references = json.loads(references_json) if references_json else proposal.get("wall_references", [])
            dimensions = json.loads(dimensions_json) if dimensions_json else proposal.get("wall_dimensions", [])
            for d in dimensions:
                for end in ("start", "end"):
                    endpoint = d[end]
                    x, y = endpoint["pixel"]
                    with PILImage.open(toolkit.image_path(endpoint["image"])) as pic:
                        if not (0 <= x < pic.width and 0 <= y < pic.height):
                            raise ValueError("dimension endpoint outside original image")
            walls = resolve_wall_references(source, references)
            result = {"candidate": candidate, "source_model_sha256": source["source_model_sha256"],
                      "dimension_report": convert_wall_dimensions(walls, dimensions), "walls": walls}
            if include_inventory or not references:
                if not 1 <= limit <= 50 or offset < 0:
                    raise ValueError('inventory requires offset >= 0 and limit 1..50')
                if floor_id is not None and floor_id not in {f['id'] for f in source['floors']}:
                    raise ValueError('unknown floor_id')
                selected_spaces = {s['id'] for s in source['spaces']
                                   if floor_id is None or s['floor_id'] == floor_id}
                inventory = [{k: b[k] for k in ('id', 'space_id', 'vertices', 'counterpart_ids')}
                             for b in source['boundaries'] if b['geometry_type'] == 'wall'
                             and b['space_id'] in selected_spaces]
                result['boundary_inventory'] = inventory[offset:offset+limit]
                result['boundary_inventory_page'] = {'floor_id':floor_id, 'total':len(inventory),
                    'offset':offset, 'returned':len(result['boundary_inventory']),
                    'next_offset':offset+limit if offset+limit < len(inventory) else None}
            toolkit.log("check_wall_dimensions", result)
            return result

        @server.tool()
        def inspect_candidate(candidate: str = "seed", include_geometry: bool = True,
                              floor_id: str | None = None) -> dict:
            """Read a saved candidate's proposal and production geometry checks.
            include_geometry=False returns notes/frame and a floor summary without
            the expanded rooms/apertures; useful for registration of large candidates.
            floor_id selects one floor. If geometry is still too large, the response
            keeps only the summary; read_candidate_items pages cells/windows/openings.
            A selected page is NOT a whole replacement proposal.
            No independent evaluation or reference answer is exposed.
            """
            path = toolkit.candidate_path(candidate)
            proposal = json.loads((path/"proposal.json").read_text())
            original_geometry = proposal['geometry']
            floors = [{'id': f['name'], 'z_floor': f['z_floor'], 'height': f['ceiling_height'],
                       'space_count': len(f['cells'])} for f in proposal['geometry']['floors']]
            if floor_id is not None:
                selected = [f for f in original_geometry['floors'] if f['name'] == floor_id]
                if not selected:
                    raise ValueError('unknown floor_id')
                ids = {cell['id'] for f in selected for cell in f['cells']}
                proposal['geometry'] = {**original_geometry, 'floors':selected,
                    'windows':[w for w in original_geometry.get('windows',[]) if w['floor'] == floor_id],
                    'openings':[o for o in original_geometry.get('openings',[])
                                if o['space_id'] in ids or o.get('other_space_id') in ids]}
            summary_due_to_size = include_geometry and len(json.dumps(proposal)) > 22000
            if summary_due_to_size:
                include_geometry = False
            if not include_geometry:
                proposal = {key: value for key, value in proposal.items() if key != 'geometry'}
            report = json.loads((path/"report.json").read_text())
            from src.agent.roles import room_use_review
            source_path = path / "source_model.json"
            result = {"candidate": candidate, "proposal": proposal, "floors": floors,
                      "room_use_review": room_use_review(json.loads(source_path.read_text()))
                          if source_path.exists() else None,
                      "geometry_included": include_geometry,
                      'floor_filter':floor_id, 'summary_due_to_size':summary_due_to_size,
                      'geometry_read_hint':'Use floor_id or read_candidate_items for bounded reads; partial results must not replace the full proposal.',
                      "wall_dimension_report": report.get("wall_dimension_report"),
                      "source_validation": report.get("source_validation"),
                      "counts": report.get("counts"),
                      "remaining_seconds": toolkit.remaining_seconds()}
            toolkit.log("inspect_candidate", {"candidate": candidate, 'include_geometry': include_geometry})
            return result

        @server.tool()
        def read_candidate_items(candidate: str, collection: str, floor_id: str | None = None,
                                 offset: int = 0, limit: int = 20) -> dict:
            """Read exact saved proposal cells, windows, openings or unsupported records.
            collection is cells/windows/openings/unsupported; floor_id optionally narrows it.
            Each cell includes floor_id. Read next_offset for more; page_is_partial
            means this is not a complete build_bim input. Prefer revise_bim to keep
            unexamined objects. This reads the proposal, not mesh/GT observations.
            """
            if collection not in {'cells','windows','openings','unsupported'}:
                raise ValueError('collection must be cells, windows, openings or unsupported')
            if not 1 <= limit <= 50 or offset < 0:
                raise ValueError('requires offset >= 0 and limit 1..50')
            proposal_path = toolkit.candidate_path(candidate)/'proposal.json'
            geometry = json.loads(proposal_path.read_text())['geometry']
            if floor_id is not None and floor_id not in {f['name'] for f in geometry['floors']}:
                raise ValueError('unknown floor_id')
            floors = [f for f in geometry['floors'] if floor_id is None or f['name'] == floor_id]
            cells = [{**c,'floor_id':f['name']} for f in floors for c in f['cells']]
            ids = {c['id'] for c in cells}
            items = (cells if collection == 'cells' else
                [r for r in geometry.get('unsupported', []) if floor_id is None or r.get('floor_id') == floor_id]
                if collection == 'unsupported' else
                [w for w in geometry.get('windows',[]) if floor_id is None or w['floor'] == floor_id]
                if collection == 'windows' else
                [o for o in geometry.get('openings',[]) if floor_id is None or o['space_id'] in ids
                 or o.get('other_space_id') in ids])
            page = []
            for item in items[offset:offset+limit]:
                if len(json.dumps(page+[item])) > 18000:
                    if not page:
                        raise ValueError('single object exceeds reply size; exact proposal remains on disk')
                    break
                page.append(item)
            result = {'candidate':candidate,'proposal_sha256':digest(proposal_path),
                'collection':collection,'floor_id':floor_id,'total':len(items),'offset':offset,
                'items':page,'returned':len(page),
                'next_offset':offset+len(page) if offset+len(page)<len(items) else None,
                'page_is_partial':True}
            toolkit.log('read_candidate_items', {k:v for k,v in result.items() if k!='items'})
            return result

        @server.tool()
        def check_source_space_relation(candidate: str, image: ImageFilename, floor_id: str,
                                        observations_json: str) -> dict:
            """Compare original-plan observations with actual source space ownership.
            observations_json is a list of {id, points:[[original_px_x,original_px_y],
            [original_px_x,original_px_y]], expected:"same_space"|"separate_spaces"|
            "uncertain", evidence:"what the original shows"}. Pick points well inside
            the observed spaces. Uses the latest registered image/floor calibration;
            first build_plan_bim or overlay_candidate if none exists. Returns actual
            space IDs and any direct door/open connection; connected does NOT mean the
            same space. Saves a source/calibration-bound review; a revised candidate
            needs its own checks. Never edits geometry or certifies drawing truth.
            """
            return toolkit.check_space_relations(candidate, image, floor_id, observations_json)

        @server.tool()
        def check_openings(candidate: str, review_json: str = "", heights_only: bool = False) -> dict:
            """List actual openings, or check original-image marks against them.
            Use heights_only=true for actual z and current height-observation coverage.
            See get_bim_reference("opening_review") for review_json. Saves a source-hash-bound
            review independently; never modifies the BIM or certifies image truth.
            """
            from src.agent.geometry.opening_review import facade_inventory, opening_inventory, review_openings
            path = toolkit.candidate_path(candidate)
            source = json.loads((path / "source_model.json").read_text())
            if heights_only:
                if review_json:
                    raise ValueError('heights_only cannot submit an opening review')
                from src.agent.execution.bim_height_coverage import height_coverage, compact_height_coverage
                result = {"candidate": candidate, "height_coverage": compact_height_coverage(
                    height_coverage(toolkit.claims(), candidate))}
            elif not review_json:
                result = {"candidate": candidate, "inventory": opening_inventory(source),
                          "facade_inventory": facade_inventory(source),
                          "drawing_fidelity": "not_evaluated"}
            else:
                observations = json.loads(review_json)
                toolkit.image_path(observations["image"])
                calibration = next((row for _, row in toolkit.registered_calibrations()
                    if (row["image"], row["floor_id"]) == (observations["image"], observations["floor_id"])), None)
                report = review_openings(source, observations, toolkit.manifest["images"],
                                        plan_calibration=calibration)
                folder = run / "opening_reviews"
                folder.mkdir(exist_ok=True)
                target = folder / f"review_{len(list(folder.glob('review_*.json'))) + 1:03d}.json"
                result = {"candidate": candidate, "review_file": str(target.relative_to(run)), **report}
                dump(target, {**result, "observations": observations})
            result["remaining_seconds"] = toolkit.remaining_seconds()
            result["input_view_status"] = toolkit.input_view_status()
            result["located_height_coverage"] = toolkit.located_heights(candidate)
            result["facade_counts"] = toolkit.facade_counts(candidate)
            toolkit.log("check_openings", result)
            return result

        @server.tool()
        def record_work_review(candidate: str, decision: str, reason: str,
                               next_action: str = "") -> dict:
            """During a continuation turn, choose continue or stop against saved work.
            Explain scope/evidence; continue requires a concrete next_action to execute
            THIS turn. A stop is a model judgment, not proof of task or image fidelity.
            """
            from scripts.tool_scripts.bim_agent_continuation import record_work_review as record
            return record(toolkit, candidate, decision, reason, next_action)

        @server.tool()
        def finish_bim(candidate: str) -> dict:
            """Select a saved BIM and persist a handoff based on actual checks.
            Unreviewed/pending scopes remain explicit. This does not certify image
            fidelity or prevent further work; call again to choose another candidate.
            """
            result = toolkit.delivery(candidate, selection_origin="agent_selected")
            dump(run / "delivery_selection.json", {
                "candidate": candidate, "source_model_sha256": result["source_model_sha256"]})
            toolkit.log("finish_bim", result)
            return {**delivery_tool_reply(result),
                    "remaining_seconds": toolkit.remaining_seconds()}

        @server.tool()
        def overlay_candidate(candidate: str, image: ImageFilename, floor_id: str,
                              x_anchors: list[list[float]], y_anchors: list[list[float]],
                              basis: str, box: list[int] | None = None,
                              reuse_on_revision: bool = True):
            """Project actual source geometry onto an AXIS-ALIGNED original plan.
            Each axis needs two [ORIGINAL pixel position, world metres] anchors,
            like map_pixels; basis explains the observed dimension and wall reference.
            No GT, auto-registration, perspective correction or visual verdict.
            Optional box crops the result in ORIGINAL pixels. Colours: magenta
            source boundaries, orange doors/passages, lime windows.
            Wall/evidence labels compare saved segment extents with original
            dimension pixels on this exact image. Distances depend on your
            calibration; extension-line ticks may lie outside a valid host.
            By default, this explicit caller-supplied calibration is saved and only
            reused for the same image/floor after later build_bim or revise_bim.
            """
            image_content, metadata = toolkit.project_overlay(
                candidate, image, floor_id, x_anchors, y_anchors, basis,
                trigger_action="overlay_candidate", box=box)
            if reuse_on_revision:
                calibration_path, calibration = toolkit._save_calibration(
                    candidate=candidate, image=image, floor_id=floor_id,
                    x_anchors=metadata["anchors"]["x"], y_anchors=metadata["anchors"]["y"],
                    basis=basis, metadata=metadata)
                metadata["registered_calibration"] = {
                    "calibration_id": calibration["calibration_id"],
                    "calibration_file": str(calibration_path.relative_to(run)),
                    "reuse_on_revision": True,
                }
                # This sidecar was created during this same explicit request;
                # earlier projection files are never changed or replaced.
                dump(run / metadata["overlay_image"].replace(".png", ".json"), metadata)
            else:
                metadata["registered_calibration"] = {"reuse_on_revision": False}
            toolkit.log("overlay_candidate", metadata)
            return [image_content, json.dumps(metadata)]

        @server.tool()
        def revise_bim(candidate: str, operations_json: str) -> CallToolResult:
            """Apply local edits/reflection with code and save a new checked BIM.
            See get_bim_reference("edits") for operations whose format the system prompt
            does not give. Prior candidates stay unchanged.
            Opening changes/removals and shared-wall moves require a reason and source_refs.
            set_space_role assigns catalog use and its evidence, preserving geometry.
            """
            return candidate_result(toolkit.revise(candidate, operations_json))

        @server.tool()
        def review_detail(question: str, images: list[str], timeout_seconds: float = 120) -> dict:
            """Ask the local image model (Haiku) one small visual question in a region.
            Give image names and original crop coordinates, and describe observable
            original-image evidence rather than a candidate conclusion. The submitted
            question is not text-cleaned, so this only isolates file context. At most
            two local reviews are available in this experiment. Choose 15–240
            seconds (default 120), capped by the parent's remaining time with a
            completion reserve. Keep the task small enough to return within it.
            """
            response = review_detail_observation(toolkit, question, images, timeout_seconds=timeout_seconds)
            toolkit.log("review_detail", {"question": question, "images": images,
                                          "timeout_seconds_requested": timeout_seconds,
                                          "response": response})
            return response

        @server.tool()
        def build_plan_bim(image: ImageFilename, plan_json: str) -> CallToolResult:
            """Build one floor from observed pixel wall paths, apertures and calibration.
            Read get_bim_reference('plan_partition') for the JSON contract. Code
            closes faces and finds opening hosts; it never fills wall-path gaps,
            invents partitions or trims openings. Returns actual source plan and
            original overlay images, and drawing_differences: places where the
            original's ink and your declaration disagree, to check in the original.
            Simple orthogonal outer footprint without holes, including concave
            outlines; orthogonal interior partitions.
            A draft with known omissions needs explicit
            unresolved notes. Each source export uses the shared candidate budget.
            """
            return candidate_result(toolkit.build_plan(image, plan_json))

        @server.tool()
        def assemble_plan_bim(floors_json: str) -> CallToolResult:
            """Assemble 2–32 saved pixel plans without rewriting their rooms or openings.
            Read get_bim_reference('plan_assembly'). floors_json is a JSON list; each item contains draft_id,
            expected_plan_sha256, floor_id, z_floor and evidence. Recompiles bound drafts,
            namespaces IDs and translates all opening z values by the floor-base change.
            No height scaling, plan alignment, floor copying or inferred vertical connection.
            For layer height or aperture changes first revise that draft explicitly.
            Returns actual source views/overlays for every included floor.
            """
            return candidate_result(toolkit.assemble_plans(floors_json))

        @server.tool()
        def build_parametric_bim(plan_json: str) -> CallToolResult:
            """Expand model-declared floor templates and window rows, then build source BIM.
            Read get_bim_reference('parametric') first. Never infers or trims geometry.
            Relative aperture heights are offset by each explicit instance base.
            """
            from src.agent.geometry.parametric_proposal import expand_parametric_proposal
            folder = toolkit.run / 'parametric_drafts'
            folder.mkdir(exist_ok=True)
            draft = folder / f'draft_{len(list(folder.glob("*.json")))+1:03d}.json'
            draft.write_text(plan_json)
            try:
                plan = json.loads(plan_json)
                proposal = expand_parametric_proposal(plan)
            except (ValueError, TypeError, KeyError) as error:
                result = {'error': str(error), 'draft': str(draft.relative_to(toolkit.run)),
                          'remaining_seconds': toolkit.remaining_seconds()}
                toolkit.log('build_parametric_bim', result)
                return candidate_result(result)
            result = toolkit.build(proposal, action='build_parametric_bim')
            if result.get('candidate'):
                dump(toolkit.run / result['candidate'] / 'parametric_plan.json', plan)
            # Full inventories and every plan remain on disk/available on demand.
            # Return representative template plans without repeating identical floors.
            result.pop('opening_inventory', None)
            representatives = {}
            for instance in plan['instances']:
                representatives.setdefault(instance['template'], instance['id'])
            result['source_plan_views'] = [v for v in result.get('source_plan_views', [])
                                         if v['floor_id'] in representatives.values()]
            return candidate_result(result)

        @server.tool()
        def inspect_parametric_plan(candidate: str) -> dict:
            """Read the exact saved compact plan for revision; original evidence is separate."""
            value = json.loads((toolkit.candidate_path(candidate) / 'parametric_plan.json').read_text())
            toolkit.log('inspect_parametric_plan', {'candidate': candidate})
            return value

        @server.tool()
        def build_bim(proposal_json: str) -> CallToolResult:
            """Build/check/save a candidate; get_bim_reference("geometry") describes proposal JSON.
            Returns errors or actual geometry checks. All exports share the quota
            reported by inputs.candidate_budget, including floor builds and revisions.
            """
            return candidate_result(toolkit.build(json.loads(proposal_json)))

        @server.tool()
        def view_elevation_candidate(candidate: str, facade: str, image: ImageFilename = "",
                                     horizontal_anchors: list[list[float]] | None = None,
                                     z_anchors: list[list[float]] | None = None,
                                     basis: str = "") -> CallToolResult:
            """Inspect actual source wall/window/door heights across all floors.
            facade: North, South, East or West. Set image to an exact original filename
            to receive its complete clean image alongside the source elevation and an
            ID/height table (absolute z and height above each floor). You choose the
            correspondence; no image-name inference, alignment or fidelity pass.
            The returned original view_id can be cited in claims. Omit image for source only.
            Optional calibrated overlay: provide image, horizontal_anchors and z_anchors,
            each two [original_pixel, world_metres] pairs, plus basis describing observed
            references. Horizontal metres are world x for North/South, world y for East/West
            (NOT distance from the image's left edge); z is absolute source height, not
            height above a floor. For axis-aligned drawings only. Returns clean original
            and source overlay in the same frame. Calibration is unverified; keep these
            original references unchanged when repeating after revision. No auto-fit/pass.
            """
            pictures, metadata = toolkit.elevation_view(candidate, facade, image,
                                                        horizontal_anchors, z_anchors, basis)
            return CallToolResult(content=[
                *[picture.to_image_content() for picture in pictures],
                TextContent(type="text", text=json.dumps(metadata, ensure_ascii=False)),
            ], structuredContent=metadata)

        @server.tool()
        def view_candidate(candidate: str, floor_id: str) -> Image:
            """Render a saved candidate's source-space plan, with windows blue/doors red.
            Use exact candidate from build_bim; floor_id is the proposed floor name.
            This is an inspection projection, not evidence from the original drawing.
            """
            image, metadata = toolkit.plan_view(candidate, floor_id)
            toolkit.log("view_candidate", metadata)
            return image

    if enabled_only:
        # The unfiltered service remains available for immutable version checks.
        capabilities = tool_capabilities(toolkit.manifest)
        for name in ("review_detail", "record_work_review"):
            if not readonly and not filter_tool_catalog([{"name": name}], **capabilities):
                server.remove_tool(name)
    server.run()


def run_experiment(args):
    if getattr(args, "timeout", None) is None:
        args.timeout = 6000 if getattr(args, "provider", "claude") == "glm" else 900
    if isinstance(args.timeout, bool) or not isinstance(args.timeout, (int, float)) or not math.isfinite(args.timeout) or args.timeout <= 0:
        raise ValueError("timeout must be positive finite seconds")
    max_candidates = getattr(args, "max_candidates", 24)
    if type(max_candidates) is not int or max_candidates <= 0:
        raise ValueError("max_candidates must be a positive integer")
    provider = getattr(args, "provider", "claude")
    continuation_rounds = getattr(args, "continuation_rounds", 0)
    if type(continuation_rounds) is not int or not 0 <= continuation_rounds <= 4:
        raise ValueError("continuation_rounds must be an integer from 0 to 4")
    if provider == "glm" and getattr(args, "exploratory_opus", False):
        raise ValueError("--provider glm cannot be combined with --exploratory-opus")
    seed_path = getattr(args, "resume_candidate", None)
    resume_plan_path = getattr(args, "resume_plan", None)
    plan_image = getattr(args, "plan_image", None)
    if seed_path and resume_plan_path:
        raise ValueError("--resume-plan and --resume-candidate are mutually exclusive")
    if resume_plan_path:
        if not args.images or not plan_image:
            raise ValueError("--resume-plan requires --images and --plan-image")
        if Path(plan_image).name != plan_image or not plan_image.endswith(".png"):
            raise ValueError("--plan-image must be an exact admitted PNG filename")
        if not (args.images / plan_image).is_file():
            raise ValueError(f"--plan-image {plan_image!r} is not present in --images")
        if not resume_plan_path.is_file():
            raise ValueError("--resume-plan must name an existing JSON file")
    elif plan_image:
        raise ValueError("--plan-image requires --resume-plan")
    run = args.out.resolve(); run.mkdir(parents=True, exist_ok=False)
    (run/"images").mkdir()
    images = {}
    for path in sorted(args.images.glob("*.png")) if args.images else []:
        target = run/"images"/path.name
        shutil.copy2(path,target)
        with PILImage.open(target) as im: size=list(im.size)
        images[path.name] = {"size":size,"sha256":digest(target)}
    mesh_path = getattr(args, 'mesh', None)
    if not images and mesh_path is None:
        raise ValueError("provide PNG drawings or a native --mesh GLB")
    mesh_input = None
    if mesh_path is not None:
        from scripts.tool_scripts.bim_agent_mesh import freeze_mesh
        mesh_input = freeze_mesh(mesh_path, run)
    building_input_path = getattr(args, "building_input", None)
    building_input = (freeze_building_input(building_input_path, run, images)
                      if building_input_path is not None else None)
    plan_recovery = (freeze_plan_input(resume_plan_path, run, images, plan_image)
                     if resume_plan_path is not None else None)
    generation_mode = ("saved_plan_recovery" if plan_recovery else
                       "saved_candidate_recovery" if seed_path else "original_images_agent_experiment")
    source_input_mode = ("original_images_with_building_declaration"
                         if building_input else "original_images_only")
    if mesh_input:
        source_input_mode = 'native_mesh_with_images' if images else 'native_mesh'
        if building_input:
            source_input_mode += '_with_building_declaration'
        if not seed_path and not plan_recovery:
            generation_mode = 'native_mesh_agent_experiment'
    image_kind = (getattr(args, "image_kind", None) or ("unknown" if mesh_path is not None else "drawings")
                  if images else None)
    floor_images = getattr(args, "floor_plan_images", None)
    if floor_images is not None and any(image not in images for image in floor_images):
        raise ValueError("floor_plan_images must use admitted input filenames")
    # File names are only an explicit, visible scope hint, never a hidden floor count.
    floor_scope_source = "explicit_input_filenames" if floor_images is not None else "input_filename_hint"
    if floor_images is None:
        floor_images = sorted(name for name in images if re.fullmatch(r"\d+f(?:_view)?\.png", name, re.I)) if image_kind == "drawings" else []
    started_epoch = None if getattr(args, "prepare_only", False) else time.time()
    manifest = {"images":images,"image_kind":image_kind,"scope":args.scope,"provider":provider,
                             "floor_plan_images": floor_images,
                             "floor_scope_source": floor_scope_source if floor_images else "not_declared",
                             "started_epoch": started_epoch,
                             "time_budget_seconds": args.timeout,
                             "max_candidates":max_candidates,
                             "continuation_rounds": continuation_rounds,
                             "review_detail_enabled": getattr(args, "review_detail", False),
                             "input_mode": generation_mode,
                             "exploratory_opus": getattr(args, "exploratory_opus", False),
                             "source_input_mode": source_input_mode,
                             "input_contents": {
                                 "original_png_images": {"included": bool(images), "count": len(images)},
                                 "building_declaration": {"included": bool(building_input)},
                                 "saved_generated_proposal": {"included": bool(seed_path)},
                                 "ground_truth_or_evaluation": {"included": False},
                             },
                             "deadline_epoch": (started_epoch + args.timeout if started_epoch is not None else None),
                             "implementation_sha256": {
                                 "scripts/tool_scripts/bim_agent_facade_checks.py":digest(ROOT/"scripts/tool_scripts/bim_agent_facade_checks.py"),
                                 "scripts/tool_scripts/bim_agent_feedback.py":digest(ROOT/"scripts/tool_scripts/bim_agent_feedback.py"),
                                 "scripts/tool_scripts/bim_agent_budget.py":digest(ROOT/"scripts/tool_scripts/bim_agent_budget.py"),
                                 "src/agent/correction/schema.py":digest(ROOT/"src/agent/correction/schema.py"),
                                 "src/agent/geometry/source_model.py":digest(ROOT/"src/agent/geometry/source_model.py"),
                                 "src/agent/roles.py":digest(ROOT/"src/agent/roles.py"),
                                 "src/agent/data/room_types.json":digest(ROOT/"src/agent/data/room_types.json"),
                                 "src/agent/geometry/source_naming.py":digest(ROOT/"src/agent/geometry/source_naming.py"),
                                 "scripts/tool_scripts/render_geometry_viewer.py":digest(ROOT/"scripts/tool_scripts/render_geometry_viewer.py"),
                                 "scripts/tool_scripts/run_bim_agent.py":digest(Path(__file__)),
                                 "scripts/tool_scripts/bim_agent_guidance.py":digest(ROOT/"scripts/tool_scripts/bim_agent_guidance.py"),
                                 "scripts/tool_scripts/bim_agent_continuation.py":digest(ROOT/"scripts/tool_scripts/bim_agent_continuation.py"),
                                 "src/agent/geometry/parametric_proposal.py":digest(ROOT/"src/agent/geometry/parametric_proposal.py"),
                                 "scripts/tool_scripts/bim_agent_inputs.py":digest(ROOT/"scripts/tool_scripts/bim_agent_inputs.py"),
                                 "src/agent/execution/bim_claims.py":digest(ROOT/"src/agent/execution/bim_claims.py"),
                                 "src/agent/execution/bim_claim_state.py":digest(ROOT/"src/agent/execution/bim_claim_state.py"),
                                 "src/agent/execution/bim_height_coverage.py":digest(ROOT/"src/agent/execution/bim_height_coverage.py"),
                                 "src/agent/geometry/component_attributes.py":digest(ROOT/"src/agent/geometry/component_attributes.py"),
                                 "scripts/tool_scripts/bim_agent_mesh.py":digest(ROOT/"scripts/tool_scripts/bim_agent_mesh.py"),
                                 "scripts/tool_scripts/bim_agent_inference.py":digest(ROOT/"scripts/tool_scripts/bim_agent_inference.py"),
                                 "src/agent/geometry/mesh_observation.py":digest(ROOT/"src/agent/geometry/mesh_observation.py"),
                                 "src/agent/geometry/mesh_bim_frame.py":digest(ROOT/"src/agent/geometry/mesh_bim_frame.py"),
                                 "src/agent/execution/source_proposal.py":digest(ROOT/"src/agent/execution/source_proposal.py"),
                                 "src/agent/geometry/proposal_edits.py":digest(ROOT/"src/agent/geometry/proposal_edits.py"),
                                 "src/agent/geometry/opening_review.py":digest(ROOT/"src/agent/geometry/opening_review.py"),
                                 "src/agent/geometry/bim_delivery.py":digest(ROOT/"src/agent/geometry/bim_delivery.py"),
                                 "src/agent/geometry/source_image_overlay.py":digest(ROOT/"src/agent/geometry/source_image_overlay.py"),
                                 "src/agent/geometry/source_floor_selection.py":digest(ROOT/"src/agent/geometry/source_floor_selection.py"),
                                 "src/agent/geometry/source_space_relations.py":digest(ROOT/"src/agent/geometry/source_space_relations.py"),
                                 "src/agent/geometry/source_elevation_view.py":digest(ROOT/"src/agent/geometry/source_elevation_view.py"),
                                 "src/agent/geometry/source_elevation_overlay.py":digest(ROOT/"src/agent/geometry/source_elevation_overlay.py"),
                                 "src/agent/geometry/source_plan_view.py":digest(ROOT/"src/agent/geometry/source_plan_view.py"),
                                 "src/agent/geometry/source_bim.py":digest(ROOT/"src/agent/geometry/source_bim.py"),
                                 "src/agent/geometry/wall_reference.py":digest(ROOT/"src/agent/geometry/wall_reference.py"),
                                 "src/agent/geometry/dimension_chain.py":digest(ROOT/"src/agent/geometry/dimension_chain.py"),
                                 "src/agent/geometry/facade_span_comparison.py":digest(ROOT/"src/agent/geometry/facade_span_comparison.py"),
                                 "src/agent/geometry/profile_observation_binding.py":digest(ROOT/"src/agent/geometry/profile_observation_binding.py"),
                                 "src/agent/geometry/plan_feedback.py":digest(ROOT/"src/agent/geometry/plan_feedback.py"),
                                 "src/agent/geometry/space_trace.py":digest(ROOT/"src/agent/geometry/space_trace.py"),
                                 "src/agent/geometry/plan_partition.py":digest(ROOT/"src/agent/geometry/plan_partition.py"),
                                 "src/agent/geometry/plan_assembly.py":digest(ROOT/"src/agent/geometry/plan_assembly.py"),
                                 "src/agent/geometry/plan_revision.py":digest(ROOT/"src/agent/geometry/plan_revision.py"),
                                 "src/agent/geometry/plan_wall_support.py":digest(ROOT/"src/agent/geometry/plan_wall_support.py"),
                                 "src/agent/geometry/plan_drawing_differences.py":digest(ROOT/"src/agent/geometry/plan_drawing_differences.py"),
                                 "src/agent/execution/bim_claim_facts.py":digest(ROOT/"src/agent/execution/bim_claim_facts.py"),
                                 "src/agent/geometry/plan_draft_view.py":digest(ROOT/"src/agent/geometry/plan_draft_view.py"),
                                 "src/agent/geometry/pixel_region.py":digest(ROOT/"src/agent/geometry/pixel_region.py"),
                                 "src/agent/geometry/pixel_region_overview.py":digest(ROOT/"src/agent/geometry/pixel_region_overview.py")},
                             "only_input": (
                                 "authorized original PNG images, user scope, explicitly supplied building "
                                 "declaration, and optional saved generated proposal; no GT/evaluation"
                                 if building_input else
                                 "authorized original PNG images, user scope, and optional saved generated "
                                 "proposal; no building declaration and no GT/evaluation"
                             )}
    if building_input:
        manifest["building_input"] = building_input
    if plan_recovery:
        manifest["plan_recovery"] = plan_recovery
        manifest["input_contents"]["saved_pixel_plan"] = {"included": True,
                                                         "status": "unverified_not_compiled"}
        manifest["only_input"] = (
            "authorized original PNG images, user scope, optional building declaration/mesh, "
            "and one unverified saved pixel-plan declaration; no old source BIM, report, GT or evaluation"
        )
    if mesh_input:
        manifest['mesh_input'] = mesh_input
        manifest['input_contents']['original_mesh'] = {'included': True, 'sha256': mesh_input['sha256']}
        manifest['only_input'] = ('Admitted original GLB and optional original PNGs, explicit building '
                                  'declaration, user scope and optional saved proposal. Mesh views are '
                                  'generated on demand internally; no GT/evaluation or preselected camera package.')
        if plan_recovery:
            manifest['only_input'] = (
                "admitted original GLB and PNGs, user scope, optional building declaration, "
                "and one unverified saved pixel-plan declaration; no old source BIM, report, GT or evaluation"
            )
    if seed_path:
        raw = (seed_path/"proposal.json").read_bytes()
        # Only the proposal is imported, never a report that might hold evaluation.
        proposal = json.loads(raw)
        manifest["seed"] = {"candidate": "seed", "proposal_sha256":hashlib.sha256(raw).hexdigest(),
                            "source":str(seed_path.resolve()), "mode":"previous_generated_proposal_recovery"}
        from src.agent.execution.source_proposal import export_source_proposal
        report = export_source_proposal(proposal, run/"seed", provenance=manifest["seed"])
        if not (run/"seed"/"source_model.json").exists():
            raise ValueError(f"seed cannot be materialized: {report.get('error')}")
    dump(run/"inputs.json", manifest)
    continuation = ("The previous pixel-plan declaration is available at inputs.plan_recovery.declaration "
                    f"and is bound to original image {plan_image}. It is unverified and may fail compilation; "
                    "importing it does not establish a valid source BIM. Follow this run's scope: you may "
                    "first submit it unchanged to reproduce the failure and inspect feedback, or revise "
                    "it using evidence from the supplied original."
                    if plan_recovery else
                    "A saved proposal is available as seed. Compare its actual spatial partitions, "
                    "openings and connectivity with the original images. Choose substantive "
                    "discrepancies for local review or revision, while preserving reliable geometry; "
                    "do not redo a full reading." if seed_path else
                    "Observe the exterior evidence, state architectural hypotheses for missing parts "
                    "and interiors, and build at the requested space detail. Inspect the actual saved "
                    "source against the input and repair substantive discrepancies." if mesh_input else
                    "No saved proposal is supplied; work from the original inputs.")
    declaration_prompt = (
        " A structured user building declaration is available from inputs under "
        "building_input.declaration. Preserve each field's stated meaning. In particular, "
        "thermal_zones describes downstream simulation zoning and is not the physical source-room "
        "count. Compare declaration claims with the supplied drawings and report conflicts or "
        "uncertainty explicitly."
        if building_input else
        " No structured building declaration was supplied for this experiment."
    )
    prompt = (f"Scope: {args.scope}\nBudget: {args.timeout} seconds. "
              f"Start by listing supplied inputs.{declaration_prompt} {continuation} "
              "Report limitations honestly, and finish within the budget.")
    if getattr(args, "prepare_only", False):
        (run / "task.txt").write_text(prompt, encoding="utf-8")
        (run / "guide.txt").write_text(run_guide(run), encoding="utf-8")
        prepared = {"status": "prepared_not_run", "run": str(run),
                    "model_calls": 0, "deadline_epoch": None,
                    "note": "Frozen inputs and common instructions only. An external controller must "
                            "record its model, start/deadline and receipt before claiming an experiment."}
        dump(run / "preparation.json", prepared)
        print(json.dumps(prepared, ensure_ascii=False, indent=2))
        return prepared
    record = subscription(run, prompt,
                          model="opus" if getattr(args, "exploratory_opus", False) else "sonnet",
                          name="agent", timeout=args.timeout,
                          effort=getattr(args, "effort", None),
                          exploratory_opus=getattr(args, "exploratory_opus", False))
    from scripts.tool_scripts.bim_agent_continuation import run_continuations, response_completed as completed
    def invoke_followup(prompt, *, name, timeout):
        return subscription(run, prompt,
            model="opus" if getattr(args, "exploratory_opus", False) else "sonnet",
            name=name, timeout=timeout, effort=getattr(args, "effort", None),
            exploratory_opus=getattr(args, "exploratory_opus", False),
            receipt_context={"role": "main_agent_continuation", "continuation_turn": name})
    records, continuation_status = run_continuations(Toolkit(run), record,
        max_rounds=continuation_rounds, invoke=invoke_followup, compact=delivery_tool_reply)
    record = records[-1]
    total_elapsed = round(sum(row["elapsed_seconds"] for row in records), 2)
    candidates = []
    for path in sorted(run.glob("candidate_*/report.json")):
        try:
            report = json.loads(path.read_text())
        except (OSError, ValueError) as error:
            # A hard stop may leave the newest export unfinished. Preserve the
            # failure and continue to the last readable saved building.
            report = {"status": "unreadable_after_interruption", "error": str(error)}
        candidates.append({"candidate":path.parent.name,"status":report.get("status"),
                           "source_geometry_ready":report.get("source_geometry_ready"),
                           "viewer_exists":(path.parent/"viewer.html").is_file(),
                           "counts":report.get("counts"),
                           **({"error": report["error"]} if report.get("error") else {})})
    selection = run / "delivery_selection.json"
    delivery = None
    response_completed = completed(record)
    generation_status = {"state":"completed" if response_completed else "interrupted",
                         "agent_response_completed":response_completed,
                         "elapsed_seconds":total_elapsed,
                         "continuation": continuation_status,
                         "returncode":record.get("returncode"),
                         "timed_out":record.get("timed_out", False)}
    if record.get("result", {}).get("is_error"):
        generation_status["error"] = str(record["result"].get("result", "Model invocation failed"))[:1000]
    if record.get("routing_error"):
        generation_status["error"] = record["routing_error"]
    if selection.exists() and not record.get("timed_out"):
        chosen = json.loads(selection.read_text())["candidate"]
        delivery = Toolkit(run).delivery(chosen, selection_origin="agent_selected", generation_status=generation_status)
    else:
        from scripts.tool_scripts.bim_agent_budget import fallback_selection
        chosen, origin = fallback_selection(Toolkit(run))
        if chosen:
            delivery = Toolkit(run).delivery(chosen, selection_origin=origin, generation_status=generation_status)
    receipts, cost_summary = cost_receipt_summary(run)
    summary = {"input_mode":manifest["input_mode"],
               "source_input_mode": manifest["source_input_mode"],
               "input_contents": manifest["input_contents"],
               "building_input_sha256": (building_input["raw_sha256"] if building_input else None),
               "candidate_results":candidates,
               "agent_response_completed":response_completed,
               "has_viewable_candidate":any(c["viewer_exists"] for c in candidates) or bool(delivery and delivery["viewer_exists"]),
               "elapsed_seconds":total_elapsed,"drawing_fidelity":"not_evaluated",
               "continuation": continuation_status,
               "opening_reviews":[str(p.relative_to(run)) for p in sorted((run/"opening_reviews").glob("review_*.json"))],
               "delivery": {"candidate":delivery["candidate"], "selection_origin":delivery["selection_origin"],
                            "report":"delivery.json", "viewer":"delivery.html"} if delivery else None,
               "subscription_invocations":len(receipts),
               **cost_summary,
               "not_evaluated":["independent GT comparison","human approval","EnergyPlus"],
               "estimated_cost_note":"CLI estimates are not subscription bills"}
    dump(run/"summary.json",summary)
    from src.agent.runtime_behaviour import write_behaviour_report
    write_behaviour_report(run, run / "behaviour")
    print(json.dumps(summary,ensure_ascii=False,indent=2))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    commands=parser.add_subparsers(dest="command",required=True)
    run=commands.add_parser("run")
    run.add_argument("--images",type=Path,help="Optional original PNG image directory")
    run.add_argument("--mesh",type=Path,help="Original self-contained GLB; observed on demand by the agent")
    run.add_argument("--image-kind", choices=("drawings", "mesh_views", "photos", "unknown"),
                     help="What the PNG images are; default drawings without --mesh, unknown with it")
    run.add_argument("--building-input", type=Path,
                     help="Explicit user building declaration JSON; omitted runs remain PNG-only")
    run.add_argument("--out",type=Path,required=True)
    run.add_argument("--scope",default="Reconstruct the building shown in all supplied drawings.")
    run.add_argument("--timeout",type=int,default=None, help="Seconds; default 6000 for GLM, 900 for Claude")
    run.add_argument("--floor-plan-image", dest="floor_plan_images", action="append",
                     help="Explicit expected floor-plan filename (repeat for all floors); otherwise numeric F filenames are shown as hints")
    run.add_argument("--prepare-only", action="store_true",
                     help="Freeze admitted inputs and instructions without a model call or ticking deadline")
    run.add_argument("--max-candidates", type=int, default=24,
                     help="Shared export quota for floor builds, assembly and revisions (default: 24)")
    run.add_argument("--continuation-rounds", type=int, choices=range(5), default=0,
                     help="Experimental bounded main-agent follow-ups within the SAME total deadline")
    run.add_argument("--review-detail", action="store_true",
                     help="Enable the bounded local image-model review tool")
    run.add_argument("--provider", choices=("claude", "glm"), default="claude",
                     help="Subscription route; glm uses glm-5.3-flash for main and local image tasks")
    run.add_argument("--exploratory-opus", action="store_true",
                     help="Explicit task-authorized exploratory Opus subscription run; default remains Sonnet")
    run.add_argument("--effort", choices=("low", "medium"), default="medium",
                     help="Sonnet reasoning effort for this run; local Haiku configuration is unchanged")
    recovery = run.add_mutually_exclusive_group()
    recovery.add_argument("--resume-candidate",type=Path,
                          help="Recover from a saved proposal directory, not an independent cold start")
    recovery.add_argument("--resume-plan",type=Path,
                          help="Resume from one unverified pixel-plan JSON; does not auto-build a BIM")
    run.add_argument("--plan-image", help="Exact supplied PNG filename associated with --resume-plan")
    server=commands.add_parser("serve")
    server.add_argument("run",type=Path)
    server.add_argument("--readonly",action="store_true")
    server.add_argument("--enabled-only", action="store_true",
                        help="Expose only capabilities enabled in the run manifest")
    args=parser.parse_args()
    if args.command=="serve": serve(args.run.resolve(),args.readonly, enabled_only=args.enabled_only)
    else: run_experiment(args)


if __name__=="__main__": main()
