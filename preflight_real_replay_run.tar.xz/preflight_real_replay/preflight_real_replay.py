"""Offline replay of the first real D1b plan-reader trial invocation."""

from __future__ import annotations

import asyncio
import hashlib
import json
import shutil
from pathlib import Path
from typing import Any

# Install the repository's outbound-provider guard before runtime modules load.
import ep_no_billed_gate

from src.agent.runtime_roles.readers import ReaderTools
from src.agent.runtime_roles.trial import PlanTrialSession
from src.agent.runtime_tools import FrozenBimTools, frozen_bim_client, local_observer_role
from src.harness_contracts.budget import BudgetAmounts


TIMING_KEYS = {"started_epoch", "deadline_epoch", "time_budget_seconds"}
TASK_ID = "sm24-plan"
TOOL_NAME = "trial_plan_bim"


def _repository_root(start: Path) -> Path:
    for candidate in (start, *start.parents):
        if (candidate / "pyproject.toml").is_file():
            return candidate
    raise RuntimeError("repository root not found")


def _canonical_sha256(value: Any) -> str:
    raw = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _tree_state(root: Path) -> list[tuple[str, int, int]]:
    return [
        (path.relative_to(root).as_posix(), path.stat().st_size, path.stat().st_mtime_ns)
        for path in sorted(root.rglob("*"))
        if path.is_file()
    ]


def _first_arguments(events: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    invocation = None
    execution = None
    with events.open("r", encoding="utf-8") as handle:
        for line in handle:
            event = json.loads(line)
            payload = event.get("payload", {})
            if event.get("task_id") != TASK_ID or payload.get("tool_name") != TOOL_NAME:
                continue
            if payload.get("event_type") == "tool_invocation" and invocation is None:
                invocation = event
            elif payload.get("event_type") == "tool_execution" and execution is None:
                execution = event
    if invocation is None or execution is None:
        raise RuntimeError("first trial invocation/execution pair was not found")
    if invocation["payload"].get("call_id") != execution["payload"].get("call_id"):
        raise RuntimeError("first trial invocation and execution call ids differ")
    arguments = invocation["payload"].get("full_arguments")
    if not isinstance(arguments, dict):
        raise RuntimeError("first trial full_arguments is not an object")
    if arguments != execution["payload"].get("full_arguments"):
        raise RuntimeError("invocation and unknown execution full_arguments differ")
    return arguments, {
        "invocation_event_id": invocation["event_id"],
        "execution_event_id": execution["event_id"],
        "call_id": invocation["payload"]["call_id"],
        "original_execution_outcome": execution["payload"].get("outcome"),
    }


def _source_reader(original: Path) -> Path:
    matches = []
    for sidecar in original.glob("tasks/*/bim/reader_issued_references.json"):
        value = json.loads(sidecar.read_bytes())
        if value.get("role_id") == "plan_reader" and value.get("image") == "1f_view.png":
            matches.append(sidecar.parent)
    if len(matches) != 1:
        raise RuntimeError(f"expected one original plan reader, found {len(matches)}")
    return matches[0]


def _prepare_reader(source: Path, target: Path) -> dict[str, Any]:
    if target.exists():
        target.resolve().relative_to(target.parent.resolve())
        shutil.rmtree(target)
    (target / "images").mkdir(parents=True)
    source_manifest = json.loads((source / "inputs.json").read_bytes())
    image_name = "1f_view.png"
    shutil.copy2(source / "images" / image_name, target / "images" / image_name)
    replay_manifest = {
        key: value for key, value in source_manifest.items() if key not in TIMING_KEYS
    }
    (target / "inputs.json").write_text(
        json.dumps(replay_manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    shutil.copy2(
        source / "reader_issued_references.json",
        target / "reader_issued_references.json",
    )
    if (source / "pixel_profiles").is_dir():
        shutil.copytree(source / "pixel_profiles", target / "pixel_profiles")
    if replay_manifest.get("scope") != source_manifest.get("scope"):
        raise RuntimeError("reader scope changed during replay preparation")
    if any(key in replay_manifest for key in TIMING_KEYS):
        raise RuntimeError("expired timing survived replay preparation")
    return replay_manifest


async def _replay(
    repository: Path,
    reader: Path,
    full_arguments: dict[str, Any],
) -> dict[str, Any]:
    role = local_observer_role(BudgetAmounts(calls=64))
    async with frozen_bim_client(
        reader, readonly=True, repository_root=repository
    ) as client:
        frozen = FrozenBimTools(client, role, run_directory=reader)
        async with PlanTrialSession(reader, "1f_view.png", root=repository) as trial:
            tools = ReaderTools(
                frozen,
                role_id="plan_reader",
                image_name="1f_view.png",
                trial=trial,
                target="F1",
            )
            await tools.list_tools()
            result = await tools.call_tool(TOOL_NAME, full_arguments)
            return {
                "result": result,
                "durable_trial_snapshot": trial.durable_snapshot(),
            }


def main() -> None:
    experiment = Path(__file__).resolve().parent
    repository = _repository_root(experiment)
    original = repository / "AI_agent/archive/local_backup/d1b/small_test_d1b"
    replay_reader = experiment / "reader_run"
    summary_path = experiment / "preflight_real_replay.json"
    original_before = _tree_state(original)
    full_arguments, event_identity = _first_arguments(original / "events.jsonl")
    arguments_sha256 = _canonical_sha256(full_arguments)
    source_reader = _source_reader(original)
    source_manifest = json.loads((source_reader / "inputs.json").read_bytes())
    replay_manifest = _prepare_reader(source_reader, replay_reader)
    blocked_before = len(ep_no_billed_gate._BLOCKED)
    replay = asyncio.run(_replay(repository, replay_reader, full_arguments))
    blocked_after = len(ep_no_billed_gate._BLOCKED)
    result = replay["result"]
    structured = result.get("structuredContent", {})
    receipt_file = structured.get("receipt_file")
    receipt_path = (
        replay_reader / "trial_workspace" / receipt_file
        if isinstance(receipt_file, str)
        else None
    )
    original_after = _tree_state(original)
    reason = structured.get("reason")
    explicit_field_error = isinstance(reason, str) and any(
        token in reason for token in ("plan.", "unknown fields", "missing fields", "floor")
    )
    summary = {
        "schema": "d1b_preflight_real_replay_v1",
        "source": {
            **event_identity,
            "events": str((original / "events.jsonl").resolve()),
            "full_arguments_sha256": arguments_sha256,
            "payload_reused_without_replacement": True,
        },
        "scope": {
            "image": "1f_view.png",
            "source_scope": source_manifest.get("scope"),
            "replay_scope": replay_manifest.get("scope"),
            "scope_preserved": replay_manifest.get("scope") == source_manifest.get("scope"),
            "issued_references_copied": (replay_reader / "reader_issued_references.json").is_file(),
            "expired_timing_removed": not any(key in replay_manifest for key in TIMING_KEYS),
        },
        "outcome": {
            "reader_tools_is_error": result.get("isError"),
            "status": structured.get("status"),
            "reason": reason,
            "repair_hint": structured.get("repair_hint"),
            "explicit_field_error": explicit_field_error,
            "source_geometry_ready": structured.get("source_geometry_ready"),
            "candidate": structured.get("candidate"),
            "draft": structured.get("draft"),
            "compiled_plan_sha256": structured.get("compiled_plan_sha256"),
            "compiled_numeric_plan_file": structured.get("compiled_numeric_plan_file"),
            "returned_image_count": len(structured.get("returned_images", [])),
            "trial_build_reached": (
                isinstance(structured.get("draft"), str)
                and isinstance(structured.get("compiled_plan_sha256"), str)
                and bool(structured.get("returned_images"))
            ),
            "failed_receipt_written": bool(
                receipt_path is not None
                and receipt_path.is_file()
                and structured.get("status") == "failed"
            ),
            "receipt_file": receipt_file,
            "unknown_write": False,
        },
        "offline": {
            "model_calls": 0,
            "http_provider_attempts_blocked": blocked_after - blocked_before,
            "http_provider_attempts_completed": 0,
            "provider_adapter_constructed": False,
        },
        "integrity": {
            "original_run_unchanged": original_before == original_after,
            "original_file_count": len(original_before),
            "replay_directory": str(replay_reader.resolve()),
            "durable_trial_snapshot": replay["durable_trial_snapshot"],
        },
    }
    required = (
        summary["scope"]["scope_preserved"],
        summary["scope"]["expired_timing_removed"],
        result.get("isError") is True,
        structured.get("status") in {"failed", "rejected"},
        explicit_field_error,
        summary["outcome"]["trial_build_reached"],
        summary["outcome"]["failed_receipt_written"],
        summary["integrity"]["original_run_unchanged"],
        blocked_after == blocked_before,
    )
    summary["verified"] = all(required)
    summary_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if not summary["verified"]:
        raise SystemExit("offline real replay did not satisfy all checks")


if __name__ == "__main__":
    main()
