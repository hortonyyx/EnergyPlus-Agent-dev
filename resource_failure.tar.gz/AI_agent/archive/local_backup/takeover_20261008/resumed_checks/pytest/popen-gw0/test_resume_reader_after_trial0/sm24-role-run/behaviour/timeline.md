# 行为记录：sm24-role-run

来源格式 `event_envelope_jsonl`；型号 `scripted-model`；4 次工具调用；6 轮。

| 调用报错 | 领域未成功 | 可用源稿（不等于保真通过） |
|---:|---:|---:|
| 0 | 0 | 0 |

首次建模尝试 None 秒；首份可用源稿 None 秒。

## 调用 1（events.jsonl）

| # | 时间 s | 工具 | 参数 | 返回 | 调用报错／领域未成功／可用源稿 |
|---:|---:|---|---|---|---|
| 1 | 0.862 | inputs | {} | {"conversion": "MCP image blocks moved to a user message after all tool-call replies; bytes unchanged", "image_blocks": [], "images": [], "tool_message": {"content": "{\n \"images\ …(+9747) | 0/0/0 |
| 2 | 45.073 | delegate_readers | {"tasks": [{"task_id": "sm24_plan_f1", "role_id": "plan_reader", "image": "1f_view.png", "target": "F1", "origin": "Common building southwest footprint corner; ground datum Z=0."}, …(+731) | null | 0/0/0 |
| 3 | 46.824 | submit_elevation_reading | {"orientation": "East", "view_direction": "West", "x_calibration": {"pixel_start": 373.0, "pixel_end": 2261.0, "world_start_m": 0.0, "world_end_m": 20.0}, "elevations": [{"id": "fl …(+1221) | {"conversion": "MCP image blocks moved to a user message after all tool-call replies; bytes unchanged", "image_blocks": [], "images": [], "tool_message": {"content": "{\"status\":  …(+319) | 0/0/0 |
| 4 | 49.06 | submit_elevation_reading | {"orientation": "South", "view_direction": "North", "x_calibration": {"pixel_start": 466.0, "pixel_end": 1995.0, "world_start_m": 0.0, "world_end_m": 10.0}, "elevations": [{"id": " …(+1009) | {"conversion": "MCP image blocks moved to a user message after all tool-call replies; bytes unchanged", "image_blocks": [], "images": [], "tool_message": {"content": "{\"status\":  …(+320) | 0/0/0 |

