"""Package explicitly selected local evidence; verify every archived byte."""
from pathlib import Path
import hashlib
import json
import tarfile
import sys

ROOT = Path(__file__).resolve().parents[4]
LOCAL = ROOT / 'AI_agent/archive/local_backup'
OUT = Path(__file__).resolve().parent / 'packages'
OUT.mkdir(exist_ok=True)
mode = sys.argv[1]
paths = []

def add_tree(path):
    paths.extend(p for p in path.rglob('*') if p.is_file()
                 and '__pycache__' not in p.parts and p.suffix != '.pyc')

if mode == 'original':
    for name in ('g1', 'g1-dispatch'):
        add_tree(LOCAL / name)
    add_tree(LOCAL / 'takeover_20261008/pre_repair')
    add_tree(LOCAL / 'takeover_20261008/old_worktree_evidence')
    for name in ('g1_takeover_kernel', 'g1_takeover_position'):
        paths.extend(p for p in (LOCAL / name).iterdir() if p.is_file())
    # The partial JSONL is preserved in its verified gzip form.
    paths = [p for p in paths if p != LOCAL / 'takeover_20261008/old_worktree_evidence/manifest.jsonl'
             and 'historical_replay_takeover_strict_final' not in p.parts]
elif mode == 'final':
    add_tree(LOCAL / 'g1/historical_replay_takeover_strict_final')
    for name in ('merge_checks', 'final_role_checks', 'resumed_checks',
                 'resource_recovered_checks', 'isolated_failures'):
        folder = LOCAL / 'takeover_20261008' / name
        if not folder.exists():
            continue
        paths.extend(p for p in folder.iterdir() if p.is_file())
        # Preserve full end-to-end artifacts, not all regenerative unit-test temp files.
        for p in folder.glob('pytest/popen-*/test_scripted_role_pipeline_*'):
            if p.is_dir() and not p.is_symlink() and not p.is_junction():
                add_tree(p)
    paths.extend(p for p in (LOCAL / 'takeover_20261008').iterdir() if p.is_file())
elif mode == 'resource_failure':
    add_tree(LOCAL / 'takeover_20261008/resumed_checks/pytest/popen-gw0/test_resume_reader_after_trial0')
    paths.append(Path(__file__).resolve())
else:
    raise SystemExit('unknown package mode')
paths = sorted(set(paths))
rows = []
for p in paths:
    if p.is_symlink() or not p.resolve().is_relative_to(ROOT):
        raise RuntimeError(f'Unsafe evidence path: {p}')
    if p.name.lower().startswith('.env') or p.suffix.lower() in {'.pem', '.key', '.pfx'}:
        raise RuntimeError(f'Credential-like filename requires review: {p}')
    rows.append({'path':p.relative_to(ROOT).as_posix(), 'bytes':p.stat().st_size,
                 'sha256':hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()})
manifest = OUT / (mode + '_manifest.json')
manifest.write_text(json.dumps({'files':rows}, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
archive = OUT / (mode + '.tar.gz')
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for p, row in zip(paths, rows):
        tar.add(p, arcname=row['path'], recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    for row in rows:
        with tar.extractfile(row['path']) as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == row['sha256'], row['path']
summary = {'mode': mode, 'file_count':len(rows), 'source_bytes':sum(r['bytes'] for r in rows),
    'archive_bytes':archive.stat().st_size,
    'archive_sha256':hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest(),
    'all_archived_file_hashes_verified':True}
(OUT / (mode+'_summary.json')).write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
print(json.dumps(summary), flush=True)
