@echo off
cd /d "C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-b1"
set VIRTUAL_ENV=C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-b1\.venv
set PATH=C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-b1\.venv\Scripts;%PATH%
set PYTHONUTF8=1
set PYTHONPATH=C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-b1
set OPENBLAS_NUM_THREADS=1
"C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-b1\.venv\Scripts\python.exe" -m src.agent.runtime_configuration launch "AI_agent\logs\experiments\2026-10-07_role_division_debug\role_division_debug.json" --case sm21_role_division_debug1 > "C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-b1\AI_agent\archive\local_backup\role_debug\sm21_run1.stdout.log" 2> "C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-b1\AI_agent\archive\local_backup\role_debug\sm21_run1.stderr.log"
echo exit=%ERRORLEVEL% > "C:\Users\Horton\Desktop\EnergyPlus-Agent-worktrees\runs-b1\AI_agent\archive\local_backup\role_debug\sm21_run1.exit.txt"
